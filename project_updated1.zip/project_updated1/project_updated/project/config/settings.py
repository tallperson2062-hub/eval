import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

MODEL_NAME = os.getenv("MODEL_NAME", "llama3.2:latest")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
PROJECTS_DIR = os.getenv("PROJECTS_DIR", "projects")
REPORTS_DIR = os.getenv("REPORTS_DIR", "reports")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
