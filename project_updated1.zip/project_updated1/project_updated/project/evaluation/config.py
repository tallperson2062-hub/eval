"""Evaluation configuration (thresholds, judge mode) - all overridable through environment variables."""
import os
from typing import Dict

from dotenv import load_dotenv

load_dotenv()

SOURCE_PDF = "AI_Agent_Evaluation_Metrics_Final_with_Citations.pdf"

# PDF rule: Score >= Threshold -> PASS ; Score < Threshold -> FAIL.
# Thresholds come from the PDF:
#   Tool Correctness      : 0.5 default (strict mode -> 1)
#   Argument Correctness  : 0.5 default, 0.7 in the PDF example configuration (strict mode -> 1)
#   Task Completion       : 0.7 (PDF example configuration)
#   Step Efficiency       : 0.7 (PDF example configuration)
#   Plan Quality/Adherence: not explicitly specified; the PDF gives 0.5 / 0.7 as general examples
DEFAULT_THRESHOLDS: Dict[str, float] = {
    "plan_quality": 0.5,
    "plan_adherence": 0.5,
    "tool_correctness": 0.5,
    "argument_correctness": 0.7,
    "task_completion": 0.7,
    "step_efficiency": 0.7,
}


def _truthy(value: str) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def eval_enabled() -> bool:
    return _truthy(os.getenv("EVAL_ENABLED", "true"))


def strict_mode() -> bool:
    return _truthy(os.getenv("EVAL_STRICT_MODE", "false"))


def load_thresholds() -> Dict[str, float]:
    """Default thresholds, overridable via EVAL_THRESHOLD_<METRIC_KEY> (e.g. EVAL_THRESHOLD_TASK_COMPLETION=0.8)."""
    out = dict(DEFAULT_THRESHOLDS)
    for key in out:
        raw = os.getenv(f"EVAL_THRESHOLD_{key.upper()}")
        if raw:
            try:
                out[key] = float(raw)
            except ValueError:
                pass
    return out


def judge_mode() -> str:
    """auto (LLM judge if reachable, else heuristic) | llm | heuristic | blend (mean of LLM and heuristic)."""
    mode = os.getenv("EVAL_JUDGE", "auto").strip().lower()
    return mode if mode in {"auto", "llm", "heuristic", "blend"} else "auto"


def judge_timeout() -> int:
    try:
        return int(os.getenv("EVAL_JUDGE_TIMEOUT", "180"))
    except ValueError:
        return 180
