"""Citation / reference links exactly as given in the evaluation-metrics PDF (hyperlinks of the 'Resource Citation' column)."""
from typing import Dict

CITATIONS: Dict[str, Dict[str, str]] = {
    "plan_quality": {
        "label": "DeepEval — Plan Quality",
        "url": "https://deepeval.com/docs/metrics-plan-quality",
        "resource": "DeepEval / supplied evaluation framework",
    },
    "plan_adherence": {
        "label": "DeepEval — Plan Adherence",
        "url": "https://deepeval.com/docs/metrics-plan-adherence",
        "resource": "DeepEval / supplied evaluation framework",
    },
    "tool_correctness": {
        "label": "DeepEval — Tool Correctness",
        "url": "https://deepeval.com/docs/metrics-tool-correctness",
        "resource": "DeepEval",
    },
    "argument_correctness": {
        "label": "DeepEval — Argument Correctness",
        "url": "https://deepeval.com/docs/metrics-argument-correctness",
        "resource": "DeepEval",
    },
    "task_completion": {
        "label": "DeepEval — Task Completion",
        "url": "https://deepeval.com/docs/metrics-task-completion",
        "resource": "DeepEval",
    },
    "step_efficiency": {
        "label": "DeepEval — Step Efficiency",
        "url": "https://deepeval.com/docs/metrics-step-efficiency",
        "resource": "DeepEval",
    },
}
