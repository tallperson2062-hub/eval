"""
Execution trace data model + recorder.

The trace is the *evidence* every metric is computed from: which CrewAI tasks were planned and
actually completed (with their real outputs), which tool-layer calls were made (with real
arguments/results), the pytest results and the final artifacts produced on disk.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from agents.prompt_templates import AGENT_ROLES

MAX_TEXT = 50_000

# SDLC phase of every EvoForge agent role (used to judge whether a plan is logically ordered)
ROLE_PHASE: Dict[str, int] = {
    AGENT_ROLES["requirements_analyst"]["role"]: 0,
    AGENT_ROLES["srs_author"]["role"]: 1,
    AGENT_ROLES["architect"]["role"]: 2,
    AGENT_ROLES["db_api_designer"]["role"]: 2,
    AGENT_ROLES["planner"]["role"]: 3,
    AGENT_ROLES["coder"]["role"]: 4,
    AGENT_ROLES["code_reviewer"]["role"]: 5,
    AGENT_ROLES["tester"]["role"]: 5,
    AGENT_ROLES["doc_writer"]["role"]: 6,
    AGENT_ROLES["debugger"]["role"]: 7,
}
PLANNER_ROLE = AGENT_ROLES["planner"]["role"]
DEBUGGER_ROLE = AGENT_ROLES["debugger"]["role"]


def clip(value: Any, limit: int = MAX_TEXT) -> Any:
    if isinstance(value, str) and len(value) > limit:
        return value[:limit] + f"...[truncated {len(value) - limit} chars]"
    return value


@dataclass
class PlannedStep:
    crew_id: int
    position: int
    agent_role: str
    description: str
    expected_output: str

    @property
    def key(self) -> str:
        return f"{self.crew_id}:{self.position}"


@dataclass
class TaskRecord:
    seq: int
    crew_id: int
    position: int
    agent_role: str
    stage: str  # "main" | "debug"
    description: str
    output: str
    status: str  # "completed" | "empty" | "missing" | "error"
    duration_s: float = 0.0

    @property
    def key(self) -> str:
        return f"{self.crew_id}:{self.position}"


@dataclass
class ToolCallRecord:
    seq: int
    name: str
    arguments: Dict[str, Any]
    context: Dict[str, Any]
    output: Any
    success: bool
    error: Optional[str]
    duration_s: float


@dataclass
class CrewRecord:
    crew_id: int
    stage: str  # "main" | "debug"
    kind: str  # "planned" | "recovery"
    roles: List[str]
    duration_s: float = 0.0
    error: Optional[str] = None


@dataclass
class ExecutionTrace:
    flow: str  # "initial" | "change"
    project_name: str
    task_text: str
    started_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None
    expected: Dict[str, Any] = field(default_factory=dict)
    planned_steps: List[PlannedStep] = field(default_factory=list)
    crews: List[CrewRecord] = field(default_factory=list)
    tasks: List[TaskRecord] = field(default_factory=list)
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    steps: List[Dict[str, Any]] = field(default_factory=list)  # unified ordered timeline
    plan_text: str = ""  # plan produced by the planner agent (Tasks.md) when the flow has one
    outcome: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    # ------------------------------------------------------------------ persistence
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)
        return path

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExecutionTrace":
        data = dict(data)
        return cls(
            flow=data["flow"],
            project_name=data["project_name"],
            task_text=data.get("task_text", ""),
            started_at=data.get("started_at", 0.0),
            finished_at=data.get("finished_at"),
            expected=data.get("expected", {}),
            planned_steps=[PlannedStep(**p) for p in data.get("planned_steps", [])],
            crews=[CrewRecord(**c) for c in data.get("crews", [])],
            tasks=[TaskRecord(**t) for t in data.get("tasks", [])],
            tool_calls=[ToolCallRecord(**t) for t in data.get("tool_calls", [])],
            steps=data.get("steps", []),
            plan_text=data.get("plan_text", ""),
            outcome=data.get("outcome", {}),
            error=data.get("error"),
        )

    @classmethod
    def load(cls, path: str) -> "ExecutionTrace":
        with open(path, "r", encoding="utf-8") as f:
            return cls.from_dict(json.load(f))

    # ------------------------------------------------------------------ helpers
    def tool_calls_named(self, name: str) -> List[ToolCallRecord]:
        return [t for t in self.tool_calls if t.name == name]


def _raw(output: Any) -> str:
    if output is None:
        return ""
    raw = getattr(output, "raw", None)
    return raw if isinstance(raw, str) else str(output)


class TraceRecorder:
    """Collects the trace while the pipeline runs. Instrumentation hooks call into this object."""

    def __init__(self, trace: ExecutionTrace):
        self.trace = trace
        self._t0 = time.time()
        self._crew_started: Dict[int, float] = {}
        self._last_mark: Dict[int, float] = {}
        self._seen: Dict[int, set] = {}
        self._tasks_by_crew: Dict[int, List[Any]] = {}

    # ---- crews / tasks -------------------------------------------------------------
    def begin_crew(self, crew: Any) -> int:
        crew_id = len(self.trace.crews)
        tasks = list(getattr(crew, "tasks", []) or [])
        roles = [getattr(getattr(t, "agent", None), "role", "unknown") for t in tasks]
        is_debug = bool(roles) and all(r == DEBUGGER_ROLE for r in roles)
        stage = "debug" if is_debug else "main"
        self.trace.crews.append(
            CrewRecord(crew_id=crew_id, stage=stage, kind="recovery" if is_debug else "planned", roles=roles)
        )
        if not is_debug:
            for pos, task in enumerate(tasks):
                self.trace.planned_steps.append(
                    PlannedStep(
                        crew_id=crew_id,
                        position=pos,
                        agent_role=roles[pos],
                        description=clip(str(getattr(task, "description", "")), 1500),
                        expected_output=clip(str(getattr(task, "expected_output", "")), 400),
                    )
                )
        now = time.time()
        self._crew_started[crew_id] = now
        self._last_mark[crew_id] = now
        self._seen[crew_id] = set()
        self._tasks_by_crew[crew_id] = tasks
        return crew_id

    def task_done(self, crew_id: int, position: int, output: Any, status: Optional[str] = None) -> None:
        if position in self._seen.get(crew_id, set()):
            return
        self._seen.setdefault(crew_id, set()).add(position)
        crew = self.trace.crews[crew_id]
        tasks = self._tasks_by_crew.get(crew_id, [])
        task = tasks[position] if position < len(tasks) else None
        raw = _raw(output)
        now = time.time()
        duration = round(now - self._last_mark.get(crew_id, now), 3)
        self._last_mark[crew_id] = now
        role = crew.roles[position] if position < len(crew.roles) else "unknown"
        rec = TaskRecord(
            seq=len(self.trace.steps),
            crew_id=crew_id,
            position=position,
            agent_role=role,
            stage=crew.stage,
            description=clip(str(getattr(task, "description", "")), 1500),
            output=clip(raw),
            status=status or ("completed" if raw.strip() else "empty"),
            duration_s=duration,
        )
        self.trace.tasks.append(rec)
        self.trace.steps.append(
            {
                "seq": rec.seq,
                "kind": "llm_task",
                "name": role,
                "stage": crew.stage,
                "status": rec.status,
                "duration_s": duration,
                "detail": clip(raw.strip().replace("\n", " "), 140),
                "ref": len(self.trace.tasks) - 1,
            }
        )
        if role == PLANNER_ROLE and raw.strip():
            self.trace.plan_text = raw

    def end_crew(self, crew_id: int, crew: Any, error: Optional[str] = None) -> None:
        # Tasks whose callback never fired: read their real output now (or mark missing).
        for pos, task in enumerate(self._tasks_by_crew.get(crew_id, [])):
            if pos in self._seen.get(crew_id, set()):
                continue
            out = getattr(task, "output", None)
            self.task_done(crew_id, pos, out, status=None if out is not None else ("error" if error else "missing"))
        rec = self.trace.crews[crew_id]
        rec.duration_s = round(time.time() - self._crew_started.get(crew_id, time.time()), 3)
        rec.error = error

    # ---- tools -----------------------------------------------------------------------
    def record_tool(
        self,
        name: str,
        arguments: Dict[str, Any],
        context: Dict[str, Any],
        output: Any,
        success: bool,
        error: Optional[str],
        duration_s: float,
    ) -> None:
        rec = ToolCallRecord(
            seq=len(self.trace.steps),
            name=name,
            arguments=arguments,
            context=context,
            output=output,
            success=success,
            error=error,
            duration_s=round(duration_s, 4),
        )
        self.trace.tool_calls.append(rec)
        self.trace.steps.append(
            {
                "seq": rec.seq,
                "kind": "tool_call",
                "name": name,
                "stage": "tool",
                "status": "ok" if success else "error",
                "duration_s": rec.duration_s,
                "detail": clip(json.dumps(arguments, default=str), 140),
                "ref": len(self.trace.tool_calls) - 1,
            }
        )
