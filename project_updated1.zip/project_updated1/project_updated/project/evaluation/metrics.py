"""
The six AI-agent evaluation metrics from the PDF, computed from an :class:`ExecutionTrace`.

PDF rule: Score >= Threshold -> PASS ; Score < Threshold -> FAIL.

    Plan Quality          = AlignmentScore(Task, Plan)
    Plan Adherence        = AlignmentScore((Task, Plan), Execution Steps)
    Tool Correctness      = Correctly Used Tools / Total Tools Called
    Argument Correctness  = Correctly Generated Input Parameters / Total Number of Tool Calls
    Task Completion       = AlignmentScore(Task, Outcome)
    Step Efficiency       = AlignmentScore(Task, Execution Steps)

Alignment scores are produced by an LLM judge when one is reachable (as in the PDF).  Every alignment metric
also computes a deterministic, trace-derived score so a result always exists and can be audited.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from evaluation import tool_specs
from evaluation.citations import CITATIONS
from evaluation.judge import LLMJudge
from evaluation.text_utils import (
    content_words, coverage, filenames_in, lcs_length, phase_first_positions, plan_items,
)
from evaluation.trace import DEBUGGER_ROLE, PLANNER_ROLE, ROLE_PHASE, ExecutionTrace


@dataclass
class MetricResult:
    key: str
    name: str
    class_name: str
    score: float
    threshold: float
    passed: bool
    reason: str
    formula: str
    definition: str
    calculation: str
    mode: str  # llm | heuristic | blend | deterministic
    citation: Dict[str, str]
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.name, "class": self.class_name, "score": round(self.score, 4),
            "threshold": self.threshold, "status": "PASS" if self.passed else "FAIL",
            "mode": self.mode, "reason": self.reason, "formula": self.formula,
            "definition": self.definition, "calculation": self.calculation,
            "citation": self.citation, "details": self.details,
        }


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _digest(obj: Any) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()


def _task_statement(trace: ExecutionTrace) -> str:
    if trace.flow == "change":
        delta = next((t.output for t in trace.tool_calls_named("detect_changes") if t.success), None) or {}
        extra = f"\nRequirement delta detected: {delta.get('summary', 'n/a')}" if delta else ""
        return (
            f"Propagate the requirement change into existing project '{trace.project_name}' - update Requirements, "
            f"SRS, Design, source code, tests and README while preserving existing functionality.\n"
            f"Updated client requirements:\n{trace.task_text}{extra}"
        )
    return (
        f"Generate the complete SDLC deliverable for project '{trace.project_name}' (requirements, SRS, design, task plan, "
        f"working Python code, passing pytest suite, README) from the client requirements:\n{trace.task_text}"
    )


def _declared_plan_lines(trace: ExecutionTrace) -> List[str]:
    return [f"{i + 1}. [{s.agent_role}] {s.description.splitlines()[0][:160]}" for i, s in enumerate(trace.planned_steps)]


def _execution_lines(trace: ExecutionTrace, limit: int = 60) -> List[str]:
    lines = []
    for s in trace.steps[:limit]:
        lines.append(f"{s['seq'] + 1}. {s['kind']} {s['name']} -> {s['status']} {s['detail'][:90]}")
    if len(trace.steps) > limit:
        lines.append(f"... (+{len(trace.steps) - limit} more steps)")
    return lines


class Metric:
    key = ""
    name = ""
    class_name = ""
    formula = ""
    definition = ""
    calculation = ""
    llm_judged = True

    def __init__(self, threshold: float, strict_mode: bool = False):
        self.strict_mode = strict_mode
        self.threshold = 1.0 if (strict_mode and self.key in {"tool_correctness", "argument_correctness"}) else threshold

    # subclasses implement: -> (heuristic_score, reason, details, llm_rubric, llm_evidence)
    def heuristic(self, trace: ExecutionTrace) -> Tuple[float, str, Dict[str, Any]]:
        raise NotImplementedError

    def llm_prompt(self, trace: ExecutionTrace) -> Optional[Tuple[str, str]]:
        return None

    def measure(self, trace: ExecutionTrace, judge: LLMJudge) -> MetricResult:
        h_score, h_reason, details = self.heuristic(trace)
        score, reason = h_score, h_reason
        mode = "heuristic" if self.llm_judged else "deterministic"
        details = dict(details)
        details["heuristic_score"] = round(h_score, 4)
        prompt = self.llm_prompt(trace) if self.llm_judged else None
        if prompt is not None and judge.wants_llm:
            verdict = judge.score(*prompt)
            if verdict is not None:
                details["llm_score"] = round(verdict["score"], 4)
                if judge.mode == "blend":
                    score, mode = (verdict["score"] + h_score) / 2, "blend"
                    reason = f"LLM: {verdict['reason']} | Trace evidence: {h_reason}"
                else:
                    score, mode, reason = verdict["score"], "llm", f"{verdict['reason']} | Trace evidence: {h_reason}"
            else:
                details["llm_unavailable"] = judge.failure or "judge returned no usable verdict"
        score = _clamp(score)
        return MetricResult(
            key=self.key, name=self.name, class_name=self.class_name, score=score, threshold=self.threshold,
            passed=score >= self.threshold, reason=reason, formula=self.formula, definition=self.definition,
            calculation=self.calculation, mode=mode, citation=CITATIONS[self.key], details=details,
        )


# =====================================================================================================
class PlanQualityMetric(Metric):
    key, name, class_name = "plan_quality", "Plan Quality", "PlanQualityMetric"
    formula = "Plan Quality Score = AlignmentScore(Task, Plan)"
    definition = "Measures whether the agent's plan is logical, complete, and aligned with the user's task."
    calculation = ("Extract the task and plan from the trace, then use an LLM to generate the alignment score. "
                   "Trace-derived fallback = 0.4*task-coverage + 0.3*logical-structure/order + 0.3*completeness.")

    def _plan(self, trace: ExecutionTrace) -> Tuple[str, str]:
        if trace.plan_text.strip():
            return trace.plan_text, "planner agent output (Tasks.md)"
        return "\n".join(_declared_plan_lines(trace)), "declared task plan of the crew(s)"

    def heuristic(self, trace):
        plan, source = self._plan(trace)
        if not plan.strip():
            return 0.0, "no plan was produced in this run", {"plan_source": "none"}
        required = content_words(trace.task_text)
        cov, missing = coverage(required, content_words(plan))
        # logical structure / order
        if trace.plan_text.strip():
            items = plan_items(plan)
            pos = phase_first_positions(plan)
            order = [n for n, _ in sorted(pos.items(), key=lambda kv: kv[1])]
            canon = ["requirements", "design", "implementation", "testing", "documentation"]
            ranks = [canon.index(n) for n in order]
            pairs = list(zip(ranks, ranks[1:]))
            ordered = (sum(1 for a, b in pairs if a <= b) / len(pairs)) if pairs else 0.0
            structure = 0.5 * min(len(items) / 3.0, 1.0) + 0.5 * ordered
            checks = {
                "lists_python_files": any(f.endswith(".py") for f in filenames_in(plan)),
                "mentions_tests": "test" in plan.lower(),
                "mentions_docs": any(w in plan.lower() for w in ("readme", "document")),
            }
            completeness = sum(checks.values()) / len(checks)
            extra = {"plan_items": len(items), "phase_order_ok": round(ordered, 3), "completeness_checks": checks}
        else:
            phases = [ROLE_PHASE.get(s.agent_role, 0) for s in trace.planned_steps]
            # The step descriptions embed the requirement text themselves, so term coverage would be trivially
            # 100%.  Use the impact analysis instead: does the plan have a step for every artifact layer the
            # requirement change actually affects?
            impact = next((t.output for t in trace.tool_calls_named("analyze_impact") if t.success), None) or {}
            layer_phase = {"requirement": 0, "srs": 1, "design": 2, "code": 4, "test": 5, "doc": 6}
            affected = [k for k, v in (impact.get("categorized_impact") or {}).items() if v and k in layer_phase]
            if affected:
                cov = sum(1 for k in affected if layer_phase[k] in phases) / len(affected)
                missing = [k for k in affected if layer_phase[k] not in phases]
                extra_cov = {"affected_layers": affected, "layers_without_plan_step": missing}
            else:
                extra_cov = {}
            pairs = list(zip(phases, phases[1:]))
            ordered = (sum(1 for a, b in pairs if a <= b) / len(pairs)) if pairs else 0.0
            structure = ordered
            expected = {0, 1, 2, 4, 5, 6} if trace.flow == "change" else {0, 1, 2, 3, 4, 5, 6}
            completeness = len(expected & set(phases)) / len(expected)
            extra = {"plan_steps": len(phases), "phase_order_ok": round(ordered, 3),
                     "sdlc_phases_covered": sorted(set(phases)), **extra_cov}
        score = 0.4 * cov + 0.3 * structure + 0.3 * completeness
        what = "of the impacted artifact layers" if (not trace.plan_text.strip() and extra.get("affected_layers")) else "of the task terms"
        reason = (f"Plan ({source}) covers {cov:.0%} {what}"
                  + (f" (missing: {', '.join(missing[:5])})" if missing else "")
                  + f"; structure/order {structure:.2f}; completeness {completeness:.2f}.")
        return score, reason, {"plan_source": source, "task_term_coverage": round(cov, 3),
                               "missing_terms": missing, "structure": round(structure, 3),
                               "completeness": round(completeness, 3), **extra}

    def llm_prompt(self, trace):
        plan, source = self._plan(trace)
        if not plan.strip():
            return None
        rubric = ("Score 0-1 how well the PLAN is logical, complete and aligned with the user's TASK "
                  "(1 = every requirement is addressed by clear, correctly ordered steps; 0 = unrelated/empty).")
        return rubric, f"TASK:\n{_task_statement(trace)[:3000]}\n\nPLAN ({source}):\n{plan[:4000]}"


# =====================================================================================================
class PlanAdherenceMetric(Metric):
    key, name, class_name = "plan_adherence", "Plan Adherence", "PlanAdherenceMetric"
    formula = "Plan Adherence Score = AlignmentScore((Task, Plan), Execution Steps)"
    definition = "Measures whether the agent actually follows its own plan during execution."
    calculation = ("Extract the task and plan, compare them with the actual execution steps, then use an LLM to "
                   "generate the alignment score. Trace-derived fallback = 0.6*ordered step completion (LCS of "
                   "planned vs executed steps) + 0.4*planned files actually produced.")

    def heuristic(self, trace):
        planned = [s.key for s in trace.planned_steps]
        if not planned:
            return 0.0, "no planned steps were recorded", {}
        executed = [t.key for t in sorted(trace.tasks, key=lambda t: t.seq)
                    if t.stage == "main" and t.status == "completed"]
        step_ratio = lcs_length(planned, executed) / len(planned)
        skipped = [k for k in planned if k not in executed]
        # files named by the planner agent's plan vs files actually written
        planned_files = {f for f in filenames_in(trace.plan_text)}
        saved = {os.path.basename(str(c.arguments.get("filename", ""))).lower()
                 for c in trace.tool_calls_named("save_artifact") if c.success}
        if planned_files:
            file_ratio = len(planned_files & saved) / len(planned_files)
            score = 0.6 * step_ratio + 0.4 * file_ratio
            missing_files = sorted(planned_files - saved)
        else:
            file_ratio, score, missing_files = None, step_ratio, []
        reason = (f"{len(planned) - len(skipped)}/{len(planned)} planned steps executed in order"
                  + (f"; {len(missing_files)} planned file(s) never written ({', '.join(missing_files[:4])})" if missing_files else "")
                  + ("." if not skipped else f"; skipped steps: {len(skipped)}."))
        return score, reason, {"planned_steps": len(planned), "executed_in_order": lcs_length(planned, executed),
                               "skipped_steps": skipped, "step_ratio": round(step_ratio, 3),
                               "planned_files": sorted(planned_files), "files_written": sorted(saved),
                               "file_ratio": None if file_ratio is None else round(file_ratio, 3),
                               "recovery_crews_run": sum(1 for c in trace.crews if c.kind == "recovery")}

    def llm_prompt(self, trace):
        if not trace.planned_steps:
            return None
        plan = trace.plan_text.strip() or "\n".join(_declared_plan_lines(trace))
        rubric = ("Score 0-1 how faithfully the EXECUTION STEPS follow the PLAN for the TASK "
                  "(1 = every planned step executed in order with no unplanned detours).")
        ev = (f"TASK:\n{_task_statement(trace)[:2000]}\n\nPLAN:\n" + "\n".join(_declared_plan_lines(trace))[:2500]
              + (f"\n\nPLANNER AGENT OUTPUT:\n{trace.plan_text[:2000]}" if trace.plan_text.strip() else "")
              + "\n\nEXECUTION STEPS:\n" + "\n".join(_execution_lines(trace)))
        return rubric, ev


# =====================================================================================================
class ToolCorrectnessMetric(Metric):
    key, name, class_name = "tool_correctness", "Tool Correctness", "ToolCorrectnessMetric"
    formula = "Tool Correctness = Correctly Used Tools / Total Tools Called"
    definition = "Measures whether the agent selected and used the appropriate/expected tool(s) for the task."
    calculation = ("A tool call is correct when the tool is in the flow's expected tool set (exact name match, as in "
                   "DeepEval) and the call executed successfully. Strict mode raises the threshold to 1.")
    llm_judged = False

    def heuristic(self, trace):
        expected = set(tool_specs.EXPECTED_TOOLS[trace.flow])
        required = tool_specs.REQUIRED_TOOLS[trace.flow]
        verdicts = []
        for c in trace.tool_calls:
            ok_name = c.name in expected
            ok = ok_name and c.success
            why = "ok" if ok else ("unexpected tool for this flow" if not ok_name else f"call failed: {c.error}")
            verdicts.append({"seq": c.seq + 1, "tool": c.name, "correct": ok, "why": why})
        total = len(verdicts)
        correct = sum(v["correct"] for v in verdicts)
        called = {c.name for c in trace.tool_calls}
        missing = [t for t in required if t not in called]
        score = (correct / total) if total else 0.0
        reason = (f"{correct}/{total} tool calls used an expected tool successfully"
                  + (f"; expected-but-never-called: {', '.join(missing)}" if missing else "") + ".") if total else \
                 "no tool calls were recorded"
        return score, reason, {"total_tool_calls": total, "correct_tool_calls": correct,
                               "expected_tools": sorted(expected), "missing_required_tools": missing,
                               "per_call": verdicts}


# =====================================================================================================
class ArgumentCorrectnessMetric(Metric):
    key, name, class_name = "argument_correctness", "Argument Correctness", "ArgumentCorrectnessMetric"
    formula = "Argument Correctness = Correctly Generated Input Parameters / Total Number of Tool Calls"
    definition = "Measures whether the arguments/input parameters generated for each tool call are correct for the task."
    calculation = ("Each tool call's arguments are checked against the tool's argument contract (type, content, "
                   "consistency with the task/earlier results); when an LLM judge is reachable it additionally decides "
                   "whether each call's arguments correctly address the task, and a call is correct only if both agree.")

    def heuristic(self, trace):
        per_call = []
        for c in trace.tool_calls:
            ok, why = tool_specs.validate_arguments(c, trace)
            per_call.append({"seq": c.seq + 1, "tool": c.name, "correct": ok, "why": why})
        total = len(per_call)
        correct = sum(p["correct"] for p in per_call)
        score = (correct / total) if total else 0.0
        bad = [f"#{p['seq']} {p['tool']} ({p['why']})" for p in per_call if not p["correct"]]
        reason = (f"{correct}/{total} tool calls had correct arguments"
                  + (f"; problems: {'; '.join(bad[:4])}" if bad else "") + ".") if total else "no tool calls were recorded"
        return score, reason, {"total_tool_calls": total, "correct_arguments": correct, "per_call": per_call}

    def measure(self, trace: ExecutionTrace, judge: LLMJudge) -> MetricResult:
        result = super().measure(trace, judge)  # deterministic contract check
        if not trace.tool_calls or not judge.wants_llm:
            return result
        items = []
        for c in trace.tool_calls:
            args = json.dumps(c.arguments, default=str)
            items.append(f"tool={c.name}; arguments={args[:350]}")
        rubric = ("For each numbered TOOL CALL decide whether its arguments correctly address the TASK below "
                  "(right file, sensible content, consistent with the task).\n"
                  f"TASK: {_task_statement(trace)[:1200]}")
        llm_flags = judge.verdicts(rubric, items)
        if llm_flags is None:
            result.details["llm_unavailable"] = judge.failure or "judge returned no usable verdicts"
            return result
        per_call = result.details["per_call"]
        for p, flag in zip(per_call, llm_flags):
            p["llm_correct"] = flag
        rule_score = result.details["heuristic_score"]
        llm_score = sum(llm_flags) / len(llm_flags)
        combined = sum(1 for p in per_call if p["correct"] and p["llm_correct"]) / len(per_call)
        if judge.mode == "blend":
            score, mode = (rule_score + llm_score) / 2, "blend"
        else:
            score, mode = combined, "llm"
        result.details["llm_score"] = round(llm_score, 4)
        result.score, result.mode = _clamp(score), mode
        result.passed = result.score >= result.threshold
        result.reason += f" LLM judge approved {sum(llm_flags)}/{len(llm_flags)} calls."
        return result


# =====================================================================================================
class TaskCompletionMetric(Metric):
    key, name, class_name = "task_completion", "Task Completion", "TaskCompletionMetric"
    formula = "Task Completion Score = AlignmentScore(Task, Outcome)"
    definition = "Measures whether the agent effectively accomplishes the user's intended task."
    calculation = ("Extract the task and outcome from the trace, then calculate how well the outcome aligns with the "
                   "task using an LLM-as-a-judge. Trace-derived fallback = 0.4*requirement coverage in the generated "
                   "code/tests + 0.3*final pytest passed + 0.2*deliverables present + 0.1*code parses.")

    def heuristic(self, trace):
        out = trace.outcome or {}
        code, tests = out.get("main_code", "") or "", out.get("test_code", "") or ""
        required = content_words(trace.task_text)
        cov, missing = coverage(required, content_words(code) | content_words(tests))
        passed = out.get("tests_passed")
        files = out.get("files", {})
        present = sum(1 for f in files.values() if f.get("exists") and f.get("chars", 0) > 0)
        deliver = (present / len(files)) if files else 0.0
        parses = 0.0
        try:
            tree = ast.parse(code)
            parses = 1.0 if any(isinstance(n, (ast.FunctionDef, ast.ClassDef)) for n in ast.walk(tree)) else 0.0
        except SyntaxError:
            parses = 0.0
        score = 0.4 * cov + 0.3 * (1.0 if passed else 0.0) + 0.2 * deliver + 0.1 * parses
        if out.get("pipeline_error"):
            score *= 0.5
        reason = (f"requirement coverage {cov:.0%}" + (f" (missing: {', '.join(missing[:5])})" if missing else "")
                  + f"; final pytest {'PASSED' if passed else 'FAILED/unknown'}; "
                  f"{present}/{len(files)} deliverables present; code {'parses' if parses else 'does not parse'}.")
        return score, reason, {"requirement_coverage": round(cov, 3), "missing_terms": missing,
                               "tests_passed": passed, "debug_attempts": out.get("debug_attempts"),
                               "deliverables_present": f"{present}/{len(files)}", "files": files,
                               "code_parses": bool(parses), "pipeline_error": out.get("pipeline_error")}

    def llm_prompt(self, trace):
        out = trace.outcome or {}
        files = ", ".join(f"{n}({'ok' if f.get('exists') and f.get('chars') else 'missing'})" for n, f in out.get("files", {}).items())
        rubric = ("Score 0-1 how completely the OUTCOME accomplishes the user's TASK "
                  "(1 = all requested functionality is implemented, tests pass and deliverables exist).")
        ev = (f"TASK:\n{_task_statement(trace)[:2500]}\n\nOUTCOME:\n- final pytest passed: {out.get('tests_passed')}\n"
              f"- debug attempts needed: {out.get('debug_attempts')}\n- deliverables: {files}\n"
              f"- main module source:\n{(out.get('main_code') or '')[:2500]}\n- tests source:\n{(out.get('test_code') or '')[:1500]}\n"
              f"- last pytest output tail:\n{(out.get('test_output_tail') or '')[-800:]}")
        return rubric, ev


# =====================================================================================================
class StepEfficiencyMetric(Metric):
    key, name, class_name = "step_efficiency", "Step Efficiency", "StepEfficiencyMetric"
    formula = "Step Efficiency Score = AlignmentScore(Task, Execution Steps)"
    definition = ("Measures how efficiently the agent executes a task, penalizing duplicate actions, repeated searches, "
                  "unnecessary retrieval, detours, loops, and speculative actions.")
    calculation = ("Extract the task and evaluate whether execution steps are necessary and direct; unnecessary actions "
                   "reduce the score. Trace-derived fallback = necessary steps / total steps, where duplicate calls, "
                   "redundant reads, failed/empty steps and agentic-debug-loop detours count as unnecessary.")

    def heuristic(self, trace):
        steps = trace.steps
        if not steps:
            return 0.0, "no execution steps were recorded", {}
        unnecessary: Dict[int, str] = {}
        seen: Dict[str, int] = {}
        mutation = 0  # increments whenever state changes (file written / committed)
        in_debug = False
        for s in steps:
            seq = s["seq"]
            if s["kind"] == "llm_task":
                rec = trace.tasks[s["ref"]]
                if rec.stage == "debug":
                    in_debug = True
                    unnecessary[seq] = "debug-loop detour (fix attempt)"
                if rec.status != "completed":
                    unnecessary.setdefault(seq, f"agent task produced no output ({rec.status})")
                continue
            call = trace.tool_calls[s["ref"]]
            if in_debug:
                unnecessary.setdefault(seq, "debug-loop detour")
                if call.name == "run_tests":
                    in_debug = False
            if not call.success:
                unnecessary.setdefault(seq, "failed tool call")
            sig = _digest([call.name, call.arguments, mutation])
            if sig in seen and call.name in {"read_artifact", "save_artifact", "commit_all", "run_tests", "load_metadata",
                                              "load_traceability_graph", "detect_changes", "analyze_impact"}:
                unnecessary.setdefault(seq, f"duplicate {call.name} (same arguments, no state change since step {seen[sig] + 1})")
            seen.setdefault(sig, seq)
            if call.name in {"save_artifact", "commit_all", "save_metadata", "save_traceability_graph"}:
                mutation += 1
        total = len(steps)
        waste = len(unnecessary)
        score = (total - waste) / total
        kinds: Dict[str, int] = {}
        for why in unnecessary.values():
            key = why.split(" (")[0]
            kinds[key] = kinds.get(key, 0) + 1
        reason = (f"{total - waste}/{total} steps were necessary and direct"
                  + (f"; unnecessary: {', '.join(f'{v}x {k}' for k, v in kinds.items())}" if kinds else "") + ".")
        return score, reason, {"total_steps": total, "necessary_steps": total - waste, "unnecessary_steps": waste,
                               "unnecessary_breakdown": kinds,
                               "unnecessary_detail": [{"step": k + 1, "why": v} for k, v in sorted(unnecessary.items())],
                               "debug_attempts": sum(1 for c in trace.crews if c.kind == "recovery")}

    def llm_prompt(self, trace):
        if not trace.steps:
            return None
        rubric = ("Score 0-1 how efficiently the EXECUTION STEPS accomplish the TASK. Penalize duplicate actions, "
                  "repeated retrieval, loops, detours (e.g. repeated debug/fix cycles) and speculative actions; "
                  "1 = every step necessary and direct.")
        return rubric, f"TASK:\n{_task_statement(trace)[:2000]}\n\nEXECUTION STEPS:\n" + "\n".join(_execution_lines(trace))


ALL_METRICS = [PlanQualityMetric, PlanAdherenceMetric, ToolCorrectnessMetric,
               ArgumentCorrectnessMetric, TaskCompletionMetric, StepEfficiencyMetric]
