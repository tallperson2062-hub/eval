"""
Tool contract of the EvoForge pipeline: which tools each flow is expected to use and the argument rules a
*correct* call must satisfy.  Used by Tool Correctness and Argument Correctness.

EvoForge agents are plain CrewAI agents without CrewAI tools; the "tools" the pipeline calls are its
tool layer (ProjectStore, PytestRunner, GitManager, TraceabilityGraph and the code-block extractors).
"""
from __future__ import annotations

import ast
import json
import os
from typing import Callable, Dict, List, Optional, Tuple

from evaluation.trace import ExecutionTrace, ToolCallRecord

TOOL_DESCRIPTIONS: Dict[str, str] = {
    "save_artifact": "Write a generated document (reports dir) or source/test file (project dir) to disk.",
    "read_artifact": "Read an existing artifact from disk to feed it to an agent.",
    "save_metadata": "Persist project metadata (requirements, files, test status).",
    "load_metadata": "Load persisted project metadata.",
    "save_traceability_graph": "Persist the requirement->code->test traceability graph.",
    "load_traceability_graph": "Load the persisted traceability graph.",
    "build_default_project_graph": "Build the traceability graph from requirements/code/test files.",
    "detect_changes": "Diff old vs new requirements (requirement delta).",
    "analyze_impact": "Traverse the traceability graph to find artifacts impacted by a change.",
    "run_tests": "Run the generated pytest suite in the project workspace.",
    "commit_all": "Commit the current project state to git.",
    "extract_code_block": "Extract a fenced code block from LLM output.",
    "extract_named_code_blocks": "Extract the (code, test) fenced blocks from LLM debug output.",
}

# Tools each flow is expected to use (anything else is an unexpected / incorrect tool selection).
EXPECTED_TOOLS: Dict[str, List[str]] = {
    "initial": [
        "extract_code_block", "extract_named_code_blocks", "save_artifact", "commit_all", "run_tests",
        "build_default_project_graph", "save_traceability_graph", "save_metadata",
    ],
    "change": [
        "load_metadata", "load_traceability_graph", "detect_changes", "analyze_impact", "read_artifact",
        "extract_code_block", "extract_named_code_blocks", "save_artifact", "commit_all", "run_tests",
        "save_metadata",
    ],
}

# Tools that a complete run of the flow must call at least once (reported as "missing" when absent).
REQUIRED_TOOLS: Dict[str, List[str]] = {
    "initial": ["extract_code_block", "save_artifact", "commit_all", "run_tests",
                "build_default_project_graph", "save_traceability_graph", "save_metadata"],
    "change": ["load_metadata", "load_traceability_graph", "detect_changes", "analyze_impact", "read_artifact",
               "extract_code_block", "save_artifact", "commit_all", "run_tests", "save_metadata"],
}

Verdict = Tuple[bool, str]


def _is_valid_python(src: str) -> Optional[str]:
    try:
        ast.parse(src)
        return None
    except SyntaxError as exc:
        return f"SyntaxError line {exc.lineno}: {exc.msg}"


def _v_save_artifact(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    a = call.arguments
    fn, content, is_code = a.get("filename"), a.get("content"), bool(a.get("is_code", False))
    if not isinstance(fn, str) or not fn.strip():
        return False, "filename missing"
    if ".." in fn.replace("\\", "/").split("/") or os.path.isabs(fn):
        return False, "unsafe path"
    if not isinstance(content, str) or not content.strip():
        return False, "empty content"
    ext = os.path.splitext(fn)[1].lower()
    if ext == ".py" and not is_code:
        return False, "python file written to the reports dir (is_code=False)"
    if ext != ".py" and is_code:
        return False, "non-python artifact written into the project (code) dir"
    if ext == ".py":
        err = _is_valid_python(content)
        if err:
            return False, f"content is not valid Python ({err})"
        if fn == trace.expected.get("test_file") and "def test_" not in content:
            return False, "test file contains no test functions"
        if fn == trace.expected.get("main_file") and not any(k in content for k in ("def ", "class ")):
            return False, "main module defines no function/class"
    if ext == ".md" and len(content.strip()) < 20:
        return False, "document is (near) empty"
    if fn == "Requirement_Delta_Report.md":
        try:
            json.loads(content)
        except ValueError:
            return False, "delta report is not valid JSON"
    return True, "ok"


def _v_read_artifact(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    fn, is_code = call.arguments.get("filename"), bool(call.arguments.get("is_code", False))
    if not isinstance(fn, str) or not fn.strip():
        return False, "filename missing"
    if (os.path.splitext(fn)[1].lower() == ".py") != is_code:
        return False, "is_code flag inconsistent with file type"
    return True, "ok"


def _v_save_metadata(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    data = call.arguments.get("data")
    if not isinstance(data, dict):
        return False, "metadata is not a dict"
    missing = [k for k in ("project_name", "requirements", "main_file", "test_status") if k not in data]
    if missing:
        return False, f"missing keys: {missing}"
    if data.get("test_status") not in ("PASSED", "FAILED"):
        return False, "test_status must be PASSED/FAILED"
    prior_runs = [t for t in trace.tool_calls if t.name == "run_tests" and t.seq < call.seq and t.success]
    if prior_runs:
        last_passed = bool((prior_runs[-1].output or {}).get("passed"))
        if (data["test_status"] == "PASSED") != last_passed:
            return False, "test_status disagrees with the last pytest run"
    if data.get("project_name") != trace.project_name:
        return False, "project_name mismatch"
    return True, "ok"


def _v_save_graph(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    g = call.arguments.get("graph")
    if not isinstance(g, dict) or not g.get("nodes"):
        return False, "traceability graph is empty"
    return True, "ok"


def _v_run_tests(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    pdir = call.context.get("project_dir", "")
    if not pdir or not os.path.isdir(pdir):
        return False, "project directory does not exist"
    if os.path.basename(pdir.rstrip("/\\")) != trace.project_name:
        return False, "tests run in the wrong project directory"
    tp = call.arguments.get("test_path")
    if tp is not None and not os.path.exists(os.path.join(pdir, str(tp))):
        return False, "test_path does not exist"
    return True, "ok"


def _v_commit_all(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    msg = call.arguments.get("message")
    if not isinstance(msg, str) or len(msg.split()) < 2:
        return False, "commit message missing / not descriptive"
    return True, "ok"


def _v_detect_changes(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    old, new = call.arguments.get("old_requirements"), call.arguments.get("new_requirements")
    if not isinstance(old, str) or not isinstance(new, str) or not new.strip():
        return False, "requirements arguments missing"
    if new.strip() != trace.task_text.strip():
        return False, "new_requirements differs from the requirements requested by the user"
    return True, "ok"


def _v_analyze_impact(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    ids = call.arguments.get("changed_node_ids")
    if not isinstance(ids, list) or not all(isinstance(i, str) for i in ids):
        return False, "changed_node_ids must be a list of ids"
    prior = [t for t in trace.tool_calls if t.name == "detect_changes" and t.seq < call.seq and t.success]
    if prior:
        changed = bool((prior[-1].output or {}).get("is_changed"))
        if changed != bool(ids):
            return False, "changed ids inconsistent with the detected requirement delta"
    return True, "ok"


def _v_build_graph(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    a = call.arguments
    if not a.get("req_list"):
        return False, "no requirements passed to the graph"
    main, test = trace.expected.get("main_file"), trace.expected.get("test_file")
    if main and main not in (a.get("code_files") or []):
        return False, "main file not linked in the graph"
    if test and test not in (a.get("test_files") or []):
        return False, "test file not linked in the graph"
    return True, "ok"


def _v_extract(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    text = call.arguments.get("text")
    if not isinstance(text, str) or not text.strip():
        return False, "no LLM text to extract from"
    lang = call.arguments.get("language", "python")
    if lang != "python":
        return False, "unexpected language"
    return True, "ok"


def _v_noargs(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    return True, "ok (no arguments)"


ARG_VALIDATORS: Dict[str, Callable[[ToolCallRecord, ExecutionTrace], Verdict]] = {
    "save_artifact": _v_save_artifact,
    "read_artifact": _v_read_artifact,
    "save_metadata": _v_save_metadata,
    "load_metadata": _v_noargs,
    "load_traceability_graph": _v_noargs,
    "save_traceability_graph": _v_save_graph,
    "build_default_project_graph": _v_build_graph,
    "detect_changes": _v_detect_changes,
    "analyze_impact": _v_analyze_impact,
    "run_tests": _v_run_tests,
    "commit_all": _v_commit_all,
    "extract_code_block": _v_extract,
    "extract_named_code_blocks": _v_extract,
}


def validate_arguments(call: ToolCallRecord, trace: ExecutionTrace) -> Verdict:
    fn = ARG_VALIDATORS.get(call.name)
    if fn is None:
        return False, "unknown tool - no argument contract"
    try:
        return fn(call, trace)
    except Exception as exc:  # defensive: a validator bug must not crash evaluation
        return False, f"validator error: {exc!r}"
