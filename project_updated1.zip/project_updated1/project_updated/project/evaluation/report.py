"""Rendering of the evaluation report: terminal table, Markdown and JSON files (with the PDF citation links)."""
from __future__ import annotations

import json
import os
import sys
import time
from typing import Any, Dict, List

from evaluation.config import SOURCE_PDF
from evaluation.citations import CITATIONS

RULE = "Score >= Threshold = PASS ; Score < Threshold = FAIL"


def _color(text: str, code: str) -> str:
    if not sys.stdout.isatty() or os.getenv("NO_COLOR"):
        return text
    return f"\033[{code}m{text}\033[0m"


def _status(passed: bool, colored: bool = True) -> str:
    label = "PASS" if passed else "FAIL"
    return _color(label, "32;1" if passed else "31;1") if colored else label


# --------------------------------------------------------------------------------------------- terminal
def render_terminal(report: Dict[str, Any]) -> str:
    rows = report["metrics"]
    w = {"m": max(len("Metric"), *(len(r["metric"]) for r in rows)), "s": 7, "t": 9, "st": 6, "mode": 13}
    line = "+" + "+".join("-" * (x + 2) for x in (w["m"], w["s"], w["t"], w["st"], w["mode"])) + "+"
    out: List[str] = []
    out.append("=" * len(line))
    out.append(" EVOFORGE - AI AGENT EVALUATION REPORT")
    out.append("=" * len(line))
    out.append(f" Project : {report['project']}   Flow: {report['flow']}   Pipeline: {report['pipeline_status']}")
    out.append(f" Judge   : {report['judge']['summary']}")
    out.append(f" Rule    : {RULE}")
    out.append(line)
    out.append(f"| {'Metric':<{w['m']}} | {'Score':>{w['s']}} | {'Threshold':>{w['t']}} | {'Status':<{w['st']}} | {'Scoring mode':<{w['mode']}} |")
    out.append(line)
    for r in rows:
        status_plain = "PASS" if r["status"] == "PASS" else "FAIL"
        pad = " " * (w["st"] - len(status_plain))
        out.append(
            f"| {r['metric']:<{w['m']}} | {r['score']:>{w['s']}.3f} | {r['threshold']:>{w['t']}.2f} | "
            f"{_status(r['status'] == 'PASS')}{pad} | {r['mode']:<{w['mode']}} |"
        )
    out.append(line)
    passed = sum(1 for r in rows if r["status"] == "PASS")
    out.append(f" Overall: {passed}/{len(rows)} metrics PASSED")
    out.append("")
    for r in rows:
        out.append(f" - {r['metric']}: {r['reason']}")
        out.append(f"   source: {r['citation']['url']}")
    if report.get("notes"):
        out.append("")
        for n in report["notes"]:
            out.append(f" ! {n}")
    out.append("")
    out.append(f" Report (md)   : {report['files'].get('markdown', '-')}")
    out.append(f" Report (json) : {report['files'].get('json', '-')}")
    out.append(f" Execution trace: {report['files'].get('trace', '-')}")
    return "\n".join(out)


# --------------------------------------------------------------------------------------------- markdown
def _compact(value: Any, limit: int = 220) -> str:
    text = json.dumps(value, default=str) if not isinstance(value, str) else value
    return text if len(text) <= limit else text[:limit] + "..."


def render_markdown(report: Dict[str, Any]) -> str:
    L: List[str] = []
    L.append(f"# EvoForge AI Agent Evaluation Report - `{report['project']}`")
    L.append("")
    L.append(f"- **Generated:** {report['generated_at']}")
    L.append(f"- **Flow evaluated:** `{report['flow']}` (pipeline status: **{report['pipeline_status']}**)")
    L.append(f"- **Judge:** {report['judge']['summary']}")
    L.append(f"- **Metric definitions/calculations source:** `{SOURCE_PDF}`")
    L.append(f"- **Pass rule:** {RULE}")
    L.append(f"- **Run size:** {report['run']['llm_tasks']} agent tasks, {report['run']['tool_calls']} tool calls, "
             f"{report['run']['steps']} total steps, {report['run']['duration_s']}s")
    L.append("")
    L.append("## Results")
    L.append("")
    L.append("| Metric | Score | Threshold | Status | Scoring mode | Source |")
    L.append("|---|---:|---:|:---:|---|---|")
    for r in report["metrics"]:
        L.append(f"| {r['metric']} (`{r['class']}`) | {r['score']:.3f} | {r['threshold']:.2f} | **{r['status']}** | "
                 f"{r['mode']} | [{r['citation']['label']}]({r['citation']['url']}) |")
    passed = sum(1 for r in report["metrics"] if r["status"] == "PASS")
    L.append("")
    L.append(f"**Overall: {passed}/{len(report['metrics'])} metrics passed.**")
    if report.get("notes"):
        L.append("")
        for n in report["notes"]:
            L.append(f"> NOTE: {n}")
    L.append("")
    L.append("## Metric details")
    for r in report["metrics"]:
        L.append("")
        L.append(f"### {r['metric']} - {r['status']} ({r['score']:.3f} vs threshold {r['threshold']:.2f})")
        L.append("")
        L.append(f"- **Definition:** {r['definition']}")
        L.append(f"- **Formula:** `{r['formula']}`")
        L.append(f"- **Calculation:** {r['calculation']}")
        L.append(f"- **Scoring mode:** {r['mode']}")
        L.append(f"- **Result:** {r['reason']}")
        L.append(f"- **Citation:** [{r['citation']['label']}]({r['citation']['url']}) - {r['citation']['resource']}")
        det = {k: v for k, v in r["details"].items() if k not in {"per_call", "unnecessary_detail", "files"}}
        if det:
            L.append("- **Evidence:**")
            for k, v in det.items():
                L.append(f"  - `{k}`: {_compact(v)}")
    L.append("")
    L.append("## Tool-call log (from the real run)")
    L.append("")
    L.append("| # | Tool | Tool correct | Arguments correct | Note |")
    L.append("|--:|---|:---:|:---:|---|")
    for row in report["tool_log"]:
        L.append(f"| {row['seq']} | `{row['tool']}` | {'yes' if row['tool_correct'] else 'NO'} | "
                 f"{'yes' if row['args_correct'] else 'NO'} | {row['note']} |")
    L.append("")
    L.append("## Execution timeline")
    L.append("")
    L.append("| # | Kind | Name | Status | Seconds | Detail |")
    L.append("|--:|---|---|---|--:|---|")
    for s in report["timeline"]:
        L.append(f"| {s['seq'] + 1} | {s['kind']} | {s['name']} | {s['status']} | {s['duration_s']} | "
                 f"{s['detail'].replace('|', '/')} |")
    L.append("")
    L.append("## References (citation links from the PDF)")
    L.append("")
    for key, c in CITATIONS.items():
        L.append(f"- {c['label']}: <{c['url']}>")
    L.append("")
    return "\n".join(L)


# --------------------------------------------------------------------------------------------- files
def write_report_files(report: Dict[str, Any], out_dir: str, flow: str) -> Dict[str, str]:
    os.makedirs(out_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    paths = {
        "json": os.path.join(out_dir, f"evaluation_report_{flow}_{stamp}.json"),
        "markdown": os.path.join(out_dir, f"evaluation_report_{flow}_{stamp}.md"),
        "latest_json": os.path.join(out_dir, "latest_evaluation_report.json"),
        "latest_markdown": os.path.join(out_dir, "latest_evaluation_report.md"),
    }
    report["files"].update({"json": paths["latest_json"], "markdown": paths["latest_markdown"]})
    md = render_markdown(report)
    js = json.dumps(report, indent=2, default=str)
    for key in ("markdown", "latest_markdown"):
        with open(paths[key], "w", encoding="utf-8") as f:
            f.write(md)
    for key in ("json", "latest_json"):
        with open(paths[key], "w", encoding="utf-8") as f:
            f.write(js)
    return paths
