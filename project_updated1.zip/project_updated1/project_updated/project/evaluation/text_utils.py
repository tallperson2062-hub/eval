"""Small deterministic text helpers used by the trace-derived (heuristic) alignment scores."""
from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Iterable, List, Sequence, Set, Tuple

STOP_WORDS = {
    "the", "and", "for", "with", "that", "this", "from", "into", "must", "should", "shall", "will", "can", "all",
    "any", "are", "was", "were", "has", "have", "its", "their", "each", "per", "not", "but", "also", "when", "then",
    "than", "use", "used", "using", "make", "build", "create", "write", "support", "supports", "supporting",
    "simple", "basic", "core", "new", "system", "module", "python", "program", "application", "app", "software",
    "function", "functions", "returns", "return", "raise", "raises", "input", "output", "number", "numbers",
    "requirement", "requirements", "following", "four", "five", "three", "two", "one", "etc", "client", "user",
    "ensure", "raised", "provide", "include", "includes", "implement", "implementation", "add", "added", "list", "file",
    "files", "data", "code", "test", "tests", "document", "documentation", "readme",
}
# Words that are stop-words in prose but are *meaningful* requirement terms here (arithmetic operations).
KEEP_WORDS = {"add", "subtract", "multiply", "divide", "power", "sum", "product", "quotient"}


def content_words(text: str) -> Set[str]:
    words: Set[str] = set()
    for raw in re.findall(r"[A-Za-z_][A-Za-z0-9_]+", text or ""):
        for part in re.sub(r"([a-z])([A-Z])", r"\1_\2", raw).lower().split("_"):
            if len(part) >= 3 and (part not in STOP_WORDS or part in KEEP_WORDS):
                words.add(part)
    return words


def words_match(a: str, b: str) -> bool:
    if a == b:
        return True
    lcp = 0
    for x, y in zip(a, b):
        if x != y:
            break
        lcp += 1
    shortest = min(len(a), len(b))
    if lcp >= 3 and lcp >= 0.6 * shortest:  # addition ~ add, multiplication ~ multiply
        return True
    return min(len(a), len(b)) >= 4 and SequenceMatcher(None, a, b).ratio() >= 0.75  # substraction ~ subtract


def coverage(required: Iterable[str], haystack: Set[str]) -> Tuple[float, List[str]]:
    """Fraction of `required` terms that (fuzzily) occur in `haystack`, plus the missing terms."""
    required = sorted(set(required))
    if not required:
        return 1.0, []
    missing = [r for r in required if not any(words_match(r, h) for h in haystack)]
    return (len(required) - len(missing)) / len(required), missing


def lcs_length(a: Sequence, b: Sequence) -> int:
    dp = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i, x in enumerate(a, 1):
        for j, y in enumerate(b, 1):
            dp[i][j] = dp[i - 1][j - 1] + 1 if x == y else max(dp[i - 1][j], dp[i][j - 1])
    return dp[len(a)][len(b)]


def plan_items(text: str) -> List[str]:
    """Numbered / bulleted / heading lines of a markdown plan."""
    items = []
    for line in (text or "").splitlines():
        if re.match(r"^\s*(?:\d+[.)]|[-*+]|#{1,6})\s+\S", line):
            items.append(line.strip())
    return items


def filenames_in(text: str) -> Set[str]:
    found = re.findall(r"[\w./-]*\w\.(?:py|md|txt|json|toml|cfg|ini)\b", text or "")
    return {f.replace("\\", "/").split("/")[-1].lower() for f in found}


PHASE_PATTERNS = [
    ("requirements", r"requirement|analy[sz]"),
    ("design", r"design|architect|schema|data model"),
    ("implementation", r"implement|source|module|code|function|class|\.py"),
    ("testing", r"test|pytest|verify|validat"),
    ("documentation", r"readme|document|docs\b|usage"),
]


def phase_first_positions(text: str) -> dict:
    low = (text or "").lower()
    out = {}
    for name, pat in PHASE_PATTERNS:
        m = re.search(pat, low)
        if m:
            out[name] = m.start()
    return out
