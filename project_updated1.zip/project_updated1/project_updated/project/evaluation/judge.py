"""
LLM-as-a-judge (local Ollama through CrewAI's LLM wrapper, same stack EvoForge uses).

The PDF defines Plan Quality / Plan Adherence / Task Completion / Step Efficiency / Argument Correctness as
LLM-judged alignment scores.  When the LLM is unreachable the metrics fall back to deterministic,
trace-derived heuristics and the report states which mode produced each score.
"""
from __future__ import annotations

import concurrent.futures
import json
import os
import re
from typing import Any, Dict, List, Optional

from evaluation import config

SYSTEM_PROMPT = (
    "You are a strict, impartial evaluator of AI agent executions. "
    "Judge only from the evidence supplied. Reply with a single JSON object and nothing else."
)


class LLMJudge:
    def __init__(self, mode: Optional[str] = None, model: Optional[str] = None, base_url: Optional[str] = None):
        self.mode = mode or config.judge_mode()
        self.model = model
        self.base_url = base_url
        self._llm = None
        self._failed: Optional[str] = None
        self.calls = 0

    # -------------------------------------------------------------- availability
    @property
    def wants_llm(self) -> bool:
        return self.mode in {"auto", "llm", "blend"}

    @property
    def failure(self) -> Optional[str]:
        return self._failed

    def _get_llm(self):
        if self._llm is None:
            from crewai import LLM
            from config.settings import MODEL_NAME, OLLAMA_BASE_URL

            name = os.environ.get("EVAL_JUDGE_MODEL") or self.model or MODEL_NAME
            model = name if name.startswith("ollama/") else f"ollama/{name}"
            self._llm = LLM(model=model, base_url=self.base_url or OLLAMA_BASE_URL, temperature=0.0)
        return self._llm

    # -------------------------------------------------------------- calls
    def ask(self, prompt: str) -> Optional[Dict[str, Any]]:
        """Return the parsed JSON object from the judge, or None if the LLM is unavailable / unusable."""
        if not self.wants_llm or self._failed:
            return None
        self.calls += 1
        try:
            llm = self._get_llm()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                fut = pool.submit(
                    llm.call,
                    [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}],
                )
                text = fut.result(timeout=config.judge_timeout())
        except Exception as exc:
            self._failed = f"{type(exc).__name__}: {str(exc)[:200]}"
            return None
        return parse_json_object(str(text))

    def score(self, rubric: str, evidence: str) -> Optional[Dict[str, Any]]:
        """Alignment-style verdict -> {"score": float in [0,1], "reason": str} or None."""
        prompt = (
            f"{rubric}\n\n{evidence}\n\n"
            'Return JSON: {"score": <number between 0 and 1>, "reason": "<one or two sentences>"}'
        )
        data = self.ask(prompt)
        if not data or "score" not in data:
            return None
        try:
            value = float(data["score"])
        except (TypeError, ValueError):
            return None
        if value > 1.0 and value <= 10.0:  # models sometimes answer on a 10-point scale
            value /= 10.0
        return {"score": max(0.0, min(1.0, value)), "reason": str(data.get("reason", "")).strip()}

    def verdicts(self, rubric: str, items: List[str]) -> Optional[List[bool]]:
        """Batch yes/no verdicts, one per numbered item -> list[bool] (same length) or None."""
        numbered = "\n".join(f"{i + 1}. {item}" for i, item in enumerate(items))
        prompt = (
            f"{rubric}\n\n{numbered}\n\n"
            'Return JSON: {"verdicts": [{"id": <number>, "correct": true|false}, ...]} with one entry per item.'
        )
        data = self.ask(prompt)
        if not data or not isinstance(data.get("verdicts"), list):
            return None
        out: Dict[int, bool] = {}
        for v in data["verdicts"]:
            try:
                out[int(v["id"])] = bool(v["correct"]) if isinstance(v["correct"], bool) else str(v["correct"]).lower() == "true"
            except (KeyError, TypeError, ValueError):
                continue
        if not all((i + 1) in out for i in range(len(items))):
            return None
        return [out[i + 1] for i in range(len(items))]


def parse_json_object(text: str) -> Optional[Dict[str, Any]]:
    text = re.sub(r"```(?:json)?", "", text)
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return None
    try:
        data = json.loads(match.group(0))
        return data if isinstance(data, dict) else None
    except ValueError:
        return None

