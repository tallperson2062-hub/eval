"""
EvoForge AI Agent Evaluation package.

Implements six agent-evaluation metrics (definitions, formulas and citations taken from
``AI_Agent_Evaluation_Metrics_Final_with_Citations.pdf``):

    Plan Quality, Plan Adherence, Tool Correctness,
    Argument Correctness, Task Completion, Step Efficiency

Scores are computed from the *real* execution trace of an EvoForge SDLC run
(CrewAI task outputs, tool-layer calls, test results, produced artifacts).
Nothing is hardcoded.  Typical use::

    from evaluation import run_with_evaluation, print_report
    result, report = run_with_evaluation(orchestrator, "create", "calc", "Build a calculator ...")
    print_report(report)
"""
from evaluation.evaluator import (  # noqa: F401
    AgentEvaluator,
    EvaluationReport,
    evaluate_latest_trace,
    print_report,
    run_with_evaluation,
)
