"""Evaluation orchestration: run sessions, snapshot the outcome, compute the six metrics, write reports."""
from __future__ import annotations

import ast
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from config.settings import PROJECTS_DIR, REPORTS_DIR
from evaluation import config, instrumentation, tool_specs
from evaluation.judge import LLMJudge
from evaluation.metrics import ALL_METRICS, MetricResult
from evaluation.report import render_terminal, write_report_files
from evaluation.trace import ExecutionTrace, TraceRecorder

DOC_FILES_INITIAL = ["Requirements.md", "SRS.md", "Design.md", "Tasks.md", "README.md", "metadata.json", "traceability_graph.json"]
DOC_FILES_CHANGE = ["Requirements.md", "SRS.md", "Design.md", "README.md", "Requirement_Delta_Report.md", "metadata.json"]


def eval_dir(project_name: str) -> str:
    return os.path.abspath(os.path.join(REPORTS_DIR, project_name, "evaluation"))


def _read(path: str) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


# ------------------------------------------------------------------------------------------------ session
class EvaluationSession:
    """Context manager: while active, every tool call / crew task of the pipeline is recorded into a trace."""

    def __init__(self, flow: str, project_name: str, requirements_text: str):
        if flow not in ("initial", "change"):
            raise ValueError("flow must be 'initial' or 'change'")
        project_dir = os.path.abspath(os.path.join(PROJECTS_DIR, project_name))
        reports_dir = os.path.abspath(os.path.join(REPORTS_DIR, project_name))
        default_main = f"{project_name.lower().replace('-', '_')}.py"
        main_file, test_file = default_main, f"test_{default_main}"
        if flow == "change":  # the pipeline reuses the files recorded in metadata.json
            meta_raw = _read(os.path.join(reports_dir, "metadata.json"))
            try:
                meta = json.loads(meta_raw) if meta_raw else {}
            except ValueError:
                meta = {}
            main_file = meta.get("main_file", main_file)
            test_file = meta.get("test_file", f"test_{main_file}")
        self.trace = ExecutionTrace(
            flow=flow, project_name=project_name, task_text=requirements_text,
            expected={"main_file": main_file, "test_file": test_file,
                      "project_dir": project_dir, "reports_dir": reports_dir},
        )
        self.recorder = TraceRecorder(self.trace)

    def __enter__(self) -> "EvaluationSession":
        instrumentation.install()
        instrumentation.set_recorder(self.recorder)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        instrumentation.set_recorder(None)  # stop recording before we snapshot (no phantom tool calls)
        self.trace.finished_at = time.time()
        if exc is not None:
            self.trace.error = f"{exc_type.__name__}: {exc}"
        return False

    def finalize(self, result: Optional[Dict[str, Any]]) -> ExecutionTrace:
        snapshot_outcome(self.trace, result)
        return self.trace


def snapshot_outcome(trace: ExecutionTrace, result: Optional[Dict[str, Any]]) -> None:
    exp = trace.expected
    main_code = _read(os.path.join(exp["project_dir"], exp["main_file"])) or ""
    test_code = _read(os.path.join(exp["project_dir"], exp["test_file"])) or ""
    files: Dict[str, Dict[str, Any]] = {}
    for name, body in ((exp["main_file"], main_code), (exp["test_file"], test_code)):
        files[name] = {"exists": bool(body), "chars": len(body)}
    docs = DOC_FILES_CHANGE if trace.flow == "change" else DOC_FILES_INITIAL
    for name in docs:
        body = _read(os.path.join(exp["reports_dir"], name))
        files[name] = {"exists": body is not None, "chars": len(body or "")}
    test_res = (result or {}).get("test_results") or {}
    trace.outcome = {
        "pipeline_status": (result or {}).get("status", "FAILED" if trace.error else "UNKNOWN"),
        "pipeline_error": trace.error,
        "tests_passed": bool(test_res.get("passed")) if test_res else None,
        "test_output_tail": (test_res.get("output") or "")[-1500:],
        "debug_attempts": (result or {}).get("debug_attempts"),
        "main_code": main_code,
        "test_code": test_code,
        "files": files,
    }


# ------------------------------------------------------------------------------------------------ evaluator
@dataclass
class EvaluationReport:
    data: Dict[str, Any]
    results: List[MetricResult] = field(default_factory=list)

    @property
    def files(self) -> Dict[str, str]:
        return self.data["files"]

    def to_dict(self) -> Dict[str, Any]:
        return self.data

    def scores(self) -> Dict[str, float]:
        return {r.key: r.score for r in self.results}

    @property
    def all_passed(self) -> bool:
        return all(r.passed for r in self.results)


class AgentEvaluator:
    def __init__(self, thresholds: Optional[Dict[str, float]] = None, judge: Optional[LLMJudge] = None,
                 strict_mode: Optional[bool] = None):
        self.thresholds = {**config.load_thresholds(), **(thresholds or {})}
        self.judge = judge or LLMJudge()
        self.strict_mode = config.strict_mode() if strict_mode is None else strict_mode

    def evaluate(self, trace: ExecutionTrace, write: bool = True, trace_path: Optional[str] = None) -> EvaluationReport:
        results = [cls(self.thresholds[cls.key], self.strict_mode).measure(trace, self.judge) for cls in ALL_METRICS]
        arg_detail = next(r for r in results if r.key == "argument_correctness").details.get("per_call", [])
        tool_detail = next(r for r in results if r.key == "tool_correctness").details.get("per_call", [])
        tool_log = []
        for t, a in zip(tool_detail, arg_detail):
            ok_args = a["correct"] and a.get("llm_correct", True)
            note = a["why"] if not a["correct"] else (t["why"] if not t["correct"] else "")
            tool_log.append({"seq": t["seq"], "tool": t["tool"], "tool_correct": t["correct"],
                             "args_correct": ok_args, "note": note})
        notes = []
        if self.judge.wants_llm and self.judge.failure:
            notes.append(f"LLM judge unavailable ({self.judge.failure}); alignment metrics used the deterministic "
                         f"trace-derived scoring instead (mode column shows 'heuristic').")
        elif self.judge.mode == "heuristic":
            notes.append("EVAL_JUDGE=heuristic: LLM judge disabled, trace-derived scoring used.")
        for w in instrumentation.warnings():
            notes.append(w)
        if trace.error:
            notes.append(f"Pipeline raised an error during the run: {trace.error}")
        duration = round((trace.finished_at or time.time()) - trace.started_at, 2)
        data: Dict[str, Any] = {
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "project": trace.project_name,
            "flow": trace.flow,
            "pipeline_status": trace.outcome.get("pipeline_status", "UNKNOWN"),
            "judge": {"mode": self.judge.mode, "llm_calls": self.judge.calls, "llm_failure": self.judge.failure,
                      "summary": (f"{self.judge.mode} (LLM judge {'unreachable -> heuristic fallback' if self.judge.failure else 'active'})"
                                  if self.judge.wants_llm else "heuristic (trace-derived, LLM judge disabled)")},
            "rule": "Score >= Threshold = PASS ; Score < Threshold = FAIL",
            "strict_mode": self.strict_mode,
            "run": {"llm_tasks": len(trace.tasks), "tool_calls": len(trace.tool_calls),
                    "steps": len(trace.steps), "duration_s": duration},
            "metrics": [r.to_dict() for r in results],
            "tool_log": tool_log,
            "timeline": trace.steps,
            "notes": notes,
            "files": {},
        }
        if write:
            out = eval_dir(trace.project_name)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            tpath = trace_path or os.path.join(out, f"trace_{trace.flow}_{stamp}.json")
            trace.save(tpath)
            trace.save(os.path.join(out, "latest_trace.json"))
            data["files"]["trace"] = os.path.join(out, "latest_trace.json")
            write_report_files(data, out, trace.flow)
        return EvaluationReport(data=data, results=results)


# ------------------------------------------------------------------------------------------------ public API
def print_report(report: Optional[EvaluationReport]) -> None:
    if report is not None:
        print("\n" + render_terminal(report.to_dict()))


def run_with_evaluation(
    run_fn: Callable[..., Dict[str, Any]], flow: str, project_name: str, requirements_text: str,
    evaluate: Optional[bool] = None,
) -> Tuple[Dict[str, Any], Optional[EvaluationReport]]:
    """
    Run an EvoForge pipeline function, e.g. ``orchestrator.run_initial_sdlc_pipeline``, with tracing, then evaluate.

    ``run_fn(project_name, requirements_text)`` is called exactly as before and its result is returned unchanged.
    Evaluation problems never break the pipeline: they are reported and ``None`` is returned for the report.
    """
    enabled = config.eval_enabled() if evaluate is None else evaluate
    if not enabled:
        return run_fn(project_name, requirements_text), None
    session = EvaluationSession(flow, project_name, requirements_text)
    result: Optional[Dict[str, Any]] = None
    try:
        with session:
            result = run_fn(project_name, requirements_text)
    finally:
        # Evaluate even if the pipeline raised; the original exception then propagates unchanged.
        try:
            trace = session.finalize(result)
            report = AgentEvaluator().evaluate(trace)
        except Exception as exc:  # noqa: BLE001
            report = None
            print(f"[Evaluation Warning] could not evaluate this run: {exc!r}")
        _last["report"] = report
    return result, report  # type: ignore[return-value]


_last: Dict[str, Any] = {"report": None}


def evaluate_latest_trace(project_name: str, trace_path: Optional[str] = None) -> EvaluationReport:
    """Re-evaluate the most recent saved trace of a project (``reports/<project>/evaluation/latest_trace.json``)."""
    path = trace_path or os.path.join(eval_dir(project_name), "latest_trace.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"No execution trace found at {path}. Run `python main.py create|change ...` (evaluation is automatic) first."
        )
    return AgentEvaluator().evaluate(ExecutionTrace.load(path))
