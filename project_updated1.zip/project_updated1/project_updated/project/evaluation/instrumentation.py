"""
Non-intrusive instrumentation.

Wrappers are installed once (idempotent) on the existing EvoForge tool layer and on ``crewai.Crew.kickoff``.
They behave exactly like the original functions: while no evaluation session is active they simply delegate,
and while a session is active they additionally *record* the call (arguments, result, timing).  The wrappers
never alter arguments, results or exceptions, so existing EvoForge functionality is unchanged.
"""
from __future__ import annotations

import functools
import inspect
import threading
import time
from typing import Any, Callable, Dict, Optional

from evaluation.trace import TraceRecorder, clip

_lock = threading.RLock()
_state: Dict[str, Any] = {"installed": False, "recorder": None, "warnings": []}


def get_recorder() -> Optional[TraceRecorder]:
    return _state["recorder"]


def set_recorder(recorder: Optional[TraceRecorder]) -> None:
    with _lock:
        _state["recorder"] = recorder


# ---------------------------------------------------------------------------------- serialisation
def _summarise_value(value: Any) -> Any:
    """JSON-friendly, size-bounded view of an argument/result."""
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return clip(value)
    if isinstance(value, dict):
        return {str(k): _summarise_value(v) for k, v in list(value.items())[:50]}
    if isinstance(value, (list, tuple, set)):
        return [_summarise_value(v) for v in list(value)[:100]]
    graph = getattr(value, "graph", None)  # TraceabilityGraph
    if graph is not None and hasattr(graph, "number_of_nodes"):
        return {"type": type(value).__name__, "nodes": graph.number_of_nodes(), "edges": graph.number_of_edges()}
    return clip(repr(value), 500)


def _summarise_result(tool: str, result: Any) -> Any:
    if tool == "run_tests" and isinstance(result, dict):
        out = dict(result)
        text = out.get("output", "") or ""
        out["output"] = text[-2500:]
        return _summarise_value(out)
    if tool == "read_artifact":
        return {"found": result is not None, "chars": len(result) if isinstance(result, str) else 0}
    if tool in {"extract_code_block"}:
        return {"chars": len(result) if isinstance(result, str) else 0}
    if tool == "extract_named_code_blocks" and isinstance(result, tuple):
        return {"code_chars": len(result[0]), "test_chars": len(result[1])}
    if tool == "load_traceability_graph":
        return _summarise_value(result)
    if tool == "build_default_project_graph":
        return {"built": True}
    if tool == "save_artifact":
        return {"path": result}
    return _summarise_value(result)


def _make_tool_wrapper(orig: Callable, tool_name: str, ctx_fn: Optional[Callable[[Any], Dict[str, Any]]]) -> Callable:
    sig = inspect.signature(orig)
    is_method = "self" in sig.parameters

    @functools.wraps(orig)
    def wrapper(*args, **kwargs):
        rec = _state["recorder"]
        if rec is None:
            return orig(*args, **kwargs)
        try:
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            arguments = {k: _summarise_value(v) for k, v in bound.arguments.items() if k != "self"}
        except TypeError:
            arguments = {"args": _summarise_value(list(args[1:] if is_method else args)), **_summarise_value(kwargs)}
        context: Dict[str, Any] = {}
        if is_method and args and ctx_fn is not None:
            try:
                context = ctx_fn(args[0])
            except Exception:
                context = {}
        start = time.time()
        try:
            result = orig(*args, **kwargs)
        except Exception as exc:  # record and re-raise unchanged
            rec.record_tool(tool_name, arguments, context, None, False, repr(exc), time.time() - start)
            raise
        try:
            rec.record_tool(tool_name, arguments, context, _summarise_result(tool_name, result), True, None, time.time() - start)
        except Exception:
            pass  # recording must never break the pipeline
        return result

    wrapper._evoforge_wrapped = True  # type: ignore[attr-defined]
    return wrapper


def _patch(owner: Any, attr: str, tool_name: str, ctx_fn: Optional[Callable] = None) -> None:
    orig = getattr(owner, attr)
    if getattr(orig, "_evoforge_wrapped", False):
        return
    setattr(owner, attr, _make_tool_wrapper(orig, tool_name, ctx_fn))


def _patch_kickoff(crew_cls: Any) -> None:
    orig = crew_cls.kickoff
    if getattr(orig, "_evoforge_wrapped", False):
        return

    @functools.wraps(orig)
    def kickoff(self, *args, **kwargs):
        rec = _state["recorder"]
        if rec is None:
            return orig(self, *args, **kwargs)
        crew_id = rec.begin_crew(self)
        saved = []
        for pos, task in enumerate(list(getattr(self, "tasks", []) or [])):
            try:
                original_cb = task.callback

                def _cb(output, _pos=pos, _orig=original_cb):
                    try:
                        rec.task_done(crew_id, _pos, output)
                    except Exception:
                        pass
                    if _orig is not None:
                        return _orig(output)

                task.callback = _cb
                saved.append((task, original_cb))
            except Exception:
                continue  # fall back to end_crew() reading task.output
        try:
            result = orig(self, *args, **kwargs)
        except Exception as exc:
            _restore(saved)
            rec.end_crew(crew_id, self, error=repr(exc))
            raise
        _restore(saved)
        rec.end_crew(crew_id, self)
        return result

    kickoff._evoforge_wrapped = True  # type: ignore[attr-defined]
    crew_cls.kickoff = kickoff


def _restore(saved) -> None:
    for task, cb in saved:
        try:
            task.callback = cb
        except Exception:
            pass


def install() -> None:
    """Idempotently install recording wrappers on the EvoForge tool layer and CrewAI."""
    with _lock:
        if _state["installed"]:
            return
        from core.git_manager import GitManager
        from core.project_store import ProjectStore
        from core.runner import PytestRunner
        from core.traceability import TraceabilityGraph

        store_ctx = lambda s: {"project_dir": s.project_dir, "reports_dir": s.reports_dir}  # noqa: E731
        _patch(ProjectStore, "save_artifact", "save_artifact", store_ctx)
        _patch(ProjectStore, "read_artifact", "read_artifact", store_ctx)
        _patch(ProjectStore, "save_metadata", "save_metadata", store_ctx)
        _patch(ProjectStore, "load_metadata", "load_metadata", store_ctx)
        _patch(ProjectStore, "save_traceability_graph", "save_traceability_graph", store_ctx)
        _patch(ProjectStore, "load_traceability_graph", "load_traceability_graph", store_ctx)
        _patch(PytestRunner, "run_tests", "run_tests", lambda s: {"project_dir": s.project_dir})
        _patch(GitManager, "commit_all", "commit_all", lambda s: {"project_dir": s.project_path})
        _patch(TraceabilityGraph, "detect_changes", "detect_changes")
        _patch(TraceabilityGraph, "analyze_impact", "analyze_impact")
        _patch(TraceabilityGraph, "build_default_project_graph", "build_default_project_graph")

        try:
            import agents.sdlc_crew as sdlc

            for fn in ("extract_code_block", "extract_named_code_blocks"):
                orig = getattr(sdlc, fn)
                if not getattr(orig, "_evoforge_wrapped", False):
                    setattr(sdlc, fn, _make_tool_wrapper(orig, fn, None))
            from crewai import Crew

            _patch_kickoff(Crew)
        except Exception as exc:  # crewai not importable -> only tool layer is traced
            _state["warnings"].append(f"CrewAI instrumentation unavailable: {exc!r}")
        _state["installed"] = True


def warnings() -> list:
    return list(_state["warnings"])
