# EvoForge - AI Agent Evaluation Metrics

Implements the six metrics from `AI_Agent_Evaluation_Metrics_Final_with_Citations.pdf`, computed from the
**real execution data** of every EvoForge run (no hardcoded scores):

| Metric | Formula (from the PDF) | Default threshold | Source |
|---|---|---:|---|
| Plan Quality | `AlignmentScore(Task, Plan)` | 0.5 | https://deepeval.com/docs/metrics-plan-quality |
| Plan Adherence | `AlignmentScore((Task, Plan), Execution Steps)` | 0.5 | https://deepeval.com/docs/metrics-plan-adherence |
| Tool Correctness | `Correctly Used Tools / Total Tools Called` | 0.5 (strict: 1) | https://deepeval.com/docs/metrics-tool-correctness |
| Argument Correctness | `Correctly Generated Input Parameters / Total Number of Tool Calls` | 0.7 (PDF example; strict: 1) | https://deepeval.com/docs/metrics-argument-correctness |
| Task Completion | `AlignmentScore(Task, Outcome)` | 0.7 | https://deepeval.com/docs/metrics-task-completion |
| Step Efficiency | `AlignmentScore(Task, Execution Steps)` | 0.7 | https://deepeval.com/docs/metrics-step-efficiency |

Pass rule (PDF): **Score >= Threshold = PASS, Score < Threshold = FAIL.**
Plan Quality / Plan Adherence thresholds are not specified in the PDF (it gives 0.5 / 0.7 as general examples); 0.5 is used and is configurable.

## Usage

Evaluation is **automatic** - nothing extra to run:

```bash
python main.py create --name calc --requirements "Build a calculator ..."   # run + evaluation table in the terminal
python main.py change --name calc --requirements "...updated requirements..."
python main.py evaluate --name calc        # re-score the latest recorded run (e.g. after changing thresholds / judge)
python demo/run_demo.py                    # end-to-end demo, prints both evaluations
streamlit run app.py                       # new "📊 Agent Evaluation" tab
python main.py create ... --no-eval        # opt out for one run (or EVAL_ENABLED=false)
```

Output (per project, in `reports/<project>/evaluation/`):

* `latest_evaluation_report.md` / `.json` (+ timestamped copies) - score, threshold, PASS/FAIL, scoring mode, reasoning,
  evidence, tool-call log, execution timeline and the **PDF citation links** for every metric
* `latest_trace.json` (+ timestamped copies) - the recorded execution trace the scores were computed from

## Where the data comes from

`evaluation/instrumentation.py` adds recording wrappers (idempotent, no-ops outside an evaluation session, never change
arguments/results/exceptions) around the existing tool layer (`ProjectStore`, `PytestRunner`, `GitManager`,
`TraceabilityGraph`, code-block extractors) and `crewai.Crew.kickoff`. The existing pipeline code in `agents/`, `core/`
is **unchanged**. The trace contains: planned CrewAI tasks, completed task outputs, the planner's plan (`Tasks.md`),
every tool call with its real arguments/results/timing, debug-loop iterations, final pytest result and generated files.

| Metric | Computed from |
|---|---|
| Plan Quality | planner agent output (initial flow) or the declared crew task plan + impact analysis (change flow) vs the task/requirements |
| Plan Adherence | planned crew steps vs tasks actually completed (in order) + files named in the plan vs files actually written |
| Tool Correctness | each recorded tool call: expected tool for the flow (exact name match) and executed successfully |
| Argument Correctness | each call's real arguments vs the tool contract (`evaluation/tool_specs.py`): valid Python written for `.py`, correct dir flag, non-empty docs, metadata consistent with the last pytest run, etc. (+ LLM verdict per call when the judge is reachable) |
| Task Completion | requested functionality present in generated code/tests, final pytest result, deliverables present, code parses |
| Step Efficiency | share of steps that were necessary: duplicate calls, redundant reads, failed/empty steps and debug-loop detours count as unnecessary |

## LLM judge vs trace-derived scoring

The PDF defines Plan Quality, Plan Adherence, Task Completion, Step Efficiency (and the per-call verdicts of Argument
Correctness) as LLM-judged. `EVAL_JUDGE` selects the mode (the report states the mode used per metric):

* `auto` (default) - use the local Ollama model as judge; if unreachable fall back to deterministic trace-derived scores
* `llm` - LLM judge only (falls back if unreachable) | `heuristic` - never call the LLM | `blend` - mean of both

The trace-derived scores are always computed and listed in the report's evidence (`heuristic_score`, `llm_score`).
Tool Correctness is deterministic by design (exact matching, as in DeepEval). Judge model: `EVAL_JUDGE_MODEL`
(defaults to `MODEL_NAME`). Thresholds: `EVAL_THRESHOLD_<METRIC>`; strict mode: `EVAL_STRICT_MODE=true`.
See `.env.example`.

## Tests

`pytest tests/test_evaluation.py` - verifies the formulas, PASS/FAIL rule, that scores change with the trace,
report/citation output, judge fallback and that instrumentation records real calls without altering behaviour.
