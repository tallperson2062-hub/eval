# my_calci
================

A simple calculator library written in Python.

## Installation
---------------

To use this library, simply clone the repository and install the required dependencies using pip:
```bash
pip install -r requirements.txt
```
## Usage
-----

### Importing Functions

You can import the calculator functions directly into your code:
```python
from my_calci import add, subtract, multiply, divide
```
Or, you can import all functions at once:
```python
from my_calci import *
```
### Calculator Functions

#### `add(a, b)`

Returns the sum of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the sum of `a` and `b`

Example:
```python
result = add(5, 3)
print(result)  # Output: 8
```
#### `subtract(a, b)`

Returns the difference between two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the difference between `a` and `b`

Example:
```python
result = subtract(5, 3)
print(result)  # Output: 2
```
#### `multiply(a, b)`

Returns the product of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the product of `a` and `b`

Example:
```python
result = multiply(5, 3)
print(result)  # Output: 15
```
#### `divide(a, b)`

Returns the quotient of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the quotient of `a` and `b`
*   Raises: `ValueError` if `b` is zero

Example:
```python
result = divide(5, 3)
print(result)  # Output: 1.6666666666666667
```
## Testing
---------

The calculator functions are thoroughly tested using the `pytest` framework.

### Test Cases

You can find the test cases in the `tests.py` file. These tests cover various scenarios, including:

*   Basic arithmetic operations (addition, subtraction, multiplication, division)
*   Edge cases (division by zero, invalid input types)

## API Documentation
-------------------

### Functions

#### `add(a, b)`

Returns the sum of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the sum of `a` and `b`

#### `subtract(a, b)`

Returns the difference between two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the difference between `a` and `b`

#### `multiply(a, b)`

Returns the product of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the product of `a` and `b`

#### `divide(a, b)`

Returns the quotient of two numbers.

*   Args: `a` (float), `b` (float)
*   Returns: `float`, the quotient of `a` and `b`
*   Raises: `ValueError` if `b` is zero

## Contributing
-------------

Contributions are welcome! If you'd like to contribute to this project, please fork the repository and submit a pull request.

## License
-------

This project is licensed under the MIT License. See the `LICENSE` file for details.