{
  "is_changed": true,
  "added_requirements": [
    "Build an in-memory task manager module with functions: add_task(title, priority), complete_task(task_id), get_pending_tasks(), delete_task(task_id), and search_tasks(keyword). Raising ValueError for invalid task IDs."
  ],
  "removed_requirements": [
    "Build an in-memory task manager module with functions: add_task(title, priority), complete_task(task_id), get_pending_tasks(), and delete_task(task_id). Raising ValueError for invalid task IDs."
  ],
  "unmodified_requirements": [],
  "summary": "Added: 1, Removed: 1, Unchanged: 0"
}