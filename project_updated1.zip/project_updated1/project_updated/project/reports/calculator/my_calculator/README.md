# my_calculator
================

A simple calculator library written in Python.

## Installation
---------------

To use this library, simply clone the repository and install the required dependencies:

```bash
git clone https://github.com/your-username/my_calculator.git
cd my_calculator
pip install -r requirements.txt
```

## Usage
-----

### Importing Functions

You can import the calculator functions directly into your Python code:

```python
from my_calculator import add, subtract, multiply, divide
```

### Calculator Functions

#### `add(a, b)`

Returns the sum of two numbers.

*   Args:
    *   `a` (float): The first number.
    *   `b` (float): The second number.
*   Returns:
    *   float: The sum of a and b.

```python
result = add(2, 3)
print(result)  # Output: 5.0
```

#### `subtract(a, b)`

Returns the difference between two numbers.

*   Args:
    *   `a` (float): The first number.
    *   `b` (float): The second number.
*   Returns:
    *   float: The difference between a and b.

```python
result = subtract(5, 3)
print(result)  # Output: 2.0
```

#### `multiply(a, b)`

Returns the product of two numbers.

*   Args:
    *   `a` (float): The first number.
    *   `b` (float): The second number.
*   Returns:
    *   float: The product of a and b.

```python
result = multiply(4, 5)
print(result)  # Output: 20.0
```

#### `divide(a, b)`

Returns the quotient of two numbers.

*   Args:
    *   `a` (float): The dividend.
    *   `b` (float): The divisor.
*   Returns:
    *   float: The quotient of a and b.
*   Raises:
    *   ValueError: If b is zero.

```python
result = divide(10, 2)
print(result)  # Output: 5.0

try:
    result = divide(5, 0)
except ValueError as e:
    print(e)  # Output: Cannot divide by zero
```

## Testing
---------

The calculator functions are thoroughly tested using the `pytest` framework.

```python
import pytest
from my_calculator import add, subtract, multiply, divide

def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    assert add(0, 0) == 0


def test_subtract():
    assert subtract(5, 3) == 2
    assert subtract(-1, 1) == -2
    assert subtract(0, 0) == 0


def test_multiply():
    assert multiply(4, 5) == 20
    assert multiply(-2, 3) == -6
    assert multiply(0, 10) == 0


def test_divide():
    assert divide(10, 2) == 5.0
    assert divide(-4, 2) == -2.0
    with pytest.raises(ValueError):
        divide(5, 0)
```

## Contributing
------------

Contributions to this project are welcome! If you'd like to contribute, please fork the repository and submit a pull request.

## License
-------

This project is licensed under the MIT License.

```markdown
# MIT License

Copyright (c) [Year] [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```