{
  "is_changed": true,
  "added_requirements": [
    "Create a calculator module supporting add(a, b), subtract(a, b), multiply(a, b), divide(a, b), and power(base, exponent). Division by 0 must raise ValueError."
  ],
  "removed_requirements": [
    "Create a calculator module supporting add(a, b), subtract(a, b), multiply(a, b), divide(a, b). Division by 0 must raise ValueError."
  ],
  "unmodified_requirements": [],
  "summary": "Added: 1, Removed: 1, Unchanged: 0"
}