# demo_calculator
================

A simple calculator implementation in Python.

## Installation
---------------

To use this calculator, simply clone or download the repository and run the `main.py` file. The calculator will be available at `http://localhost:8080`.

## Usage
-----

### Basic Operations

The calculator supports basic arithmetic operations:

*   Addition (`+`)
*   Subtraction (`-`)
*   Multiplication (`\*`)
*   Division (`/`)

You can use these operations by sending a POST request to the `/calculate` endpoint with the following JSON payload:
```json
{
    "operation": "addition",
    "numbers": [5, 3]
}
```
Replace `"addition"` with `"subtraction"`, `"multiplication"`, or `"division"` depending on the operation you want to perform.

### Example Requests

Here are some example requests:

| Operation | Request Body |
| --- | --- |
| Addition | `{"operation": "addition", "numbers": [5, 3]}` |
| Subtraction | `{"operation": "subtraction", "numbers": [5, 3]}` |
| Multiplication | `{"operation": "multiplication", "numbers": [5, 3]}` |
| Division | `{"operation": "division", "numbers": [5, 3]}` |

## API Endpoints
----------------

### `/calculate`

*   **Method:** POST
*   **Request Body:**
    *   `operation`: The operation to perform (addition, subtraction, multiplication, or division).
    *   `numbers`: A list of two numbers.
*   **Response:**
    *   `result`: The result of the calculation.

## Code
-----

The calculator is implemented in Python using the following functions:

### `add(a, b)`

Returns the sum of two numbers.

```python
def add(a, b):
    """
    Returns the sum of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    return a + b
```

### `subtract(a, b)`

Returns the difference between two numbers.

```python
def subtract(a, b):
    """
    Returns the difference between two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    return a - b
```

### `multiply(a, b)`

Returns the product of two numbers.

```python
def multiply(a, b):
    """
    Returns the product of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    return a * b
```

### `divide(a, b)`

Returns the quotient of two numbers.

```python
def divide(a, b):
    """
    Returns the quotient of two numbers.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If the divisor is zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

## Testing
---------

The calculator includes unit tests to ensure its correctness.

```python
import pytest
from demo_calculator import add, subtract, multiply, divide

def test_add():
    """Test the addition function."""
    assert add(5, 3) == 8
    assert add(-2, 4) == 2
    assert add(0, 0) == 0


def test_subtract():
    """Test the subtraction function."""
    assert subtract(5, 3) == 2
    assert subtract(-2, 4) == -6
    assert subtract(0, 0) == 0


def test_multiply():
    """Test the multiplication function."""
    assert multiply(5, 3) == 15
    assert multiply(-2, 4) == -8
    assert multiply(0, 0) == 0


def test_divide():
    """Test the division function."""
    assert divide(5, 3) == 1.6666666666666667
    assert divide(-2, 4) == -0.5
    assert divide(0, 10) == 0

with pytest.raises(ValueError):
    divide(5, 0)

def test_divide_invalid_input():
    """Test the division function with invalid input."""
    with pytest.raises(TypeError):
        divide("a", 3)
```

## Contributing
-------------

Contributions are welcome! If you'd like to contribute to this project, please fork the repository and submit a pull request.

## License
-------

This project is licensed under the MIT License. See `LICENSE` for details.