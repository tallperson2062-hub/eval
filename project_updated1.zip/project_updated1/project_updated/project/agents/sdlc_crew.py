import os
import re
import json
from typing import Dict, Any, List, Tuple
from crewai import Agent, Task, Crew, Process

from core.llm import get_ollama_llm
from core.project_store import ProjectStore
from core.traceability import TraceabilityGraph
from core.git_manager import GitManager
from core.runner import PytestRunner
from agents.prompt_templates import AGENT_ROLES

def extract_code_block(text: str, language: str = "python") -> str:
    """Extract code from markdown code block, or return text if no block."""
    pattern = rf"```(?:{language})?\n(.*?)```"
    match = re.search(pattern, text, re.DOTALL)
    if match:
        return match.group(1).strip()
    pattern_any = r"```\n(.*?)```"
    match_any = re.search(pattern_any, text, re.DOTALL)
    if match_any:
        return match_any.group(1).strip()
    return text.strip()

def extract_named_code_blocks(text: str) -> Tuple[str, str]:
    """
    Extracts python code block and pytest block if present.
    Returns (code_str, test_str).
    """
    blocks = re.findall(r"```(?:python)?\n(.*?)```", text, re.DOTALL)
    code_str = ""
    test_str = ""

    for b in blocks:
        b_clean = b.strip()
        if "def test_" in b_clean or "import pytest" in b_clean or "pytest.raises" in b_clean:
            test_str = b_clean
        elif "def " in b_clean or "class " in b_clean or "return " in b_clean:
            code_str = b_clean

    return code_str, test_str

class SDLCOrchestrator:
    """
    CrewAI SDLC Multi-Agent Orchestrator using local Ollama LLM.
    Orchestrates initial project generation and incremental requirement change propagation.
    """
    def __init__(self, model_name: str = None, base_url: str = None):
        self.llm = get_ollama_llm(model=model_name, base_url=base_url)
        self._init_agents()

    def _init_agents(self):
        """Instantiate CrewAI Agents with defined roles and Ollama LLM."""
        self.agents = {}
        for key, info in AGENT_ROLES.items():
            self.agents[key] = Agent(
                role=info["role"],
                goal=info["goal"],
                backstory=info["backstory"],
                verbose=True,
                allow_delegation=False,
                llm=self.llm
            )

    def run_initial_sdlc_pipeline(self, project_name: str, requirements_text: str) -> Dict[str, Any]:
        """
        Executes complete initial SDLC automation flow.
        """
        store = ProjectStore(project_name)
        git_mgr = GitManager(store.project_dir)

        # Step 1: Requirements Analysis Task
        req_task = Task(
            description=f"Analyze raw client requirements and output a numbered bulleted list of functional & non-functional requirements:\n{requirements_text}",
            expected_output="Numbered list of clear, actionable system requirements.",
            agent=self.agents["requirements_analyst"]
        )

        # Step 2: SRS Task
        srs_task = Task(
            description="Draft a formal Software Requirement Specification (SRS) in markdown format based on analyzed requirements.",
            expected_output="Markdown formatted SRS document.",
            agent=self.agents["srs_author"]
        )

        # Step 3: Architecture & Design Task
        design_task = Task(
            description="Design software architecture, module layout, and data models based on SRS. Output markdown design document.",
            expected_output="Markdown formatted Architecture & Design document.",
            agent=self.agents["architect"]
        )

        # Step 4: Planning Task
        plan_task = Task(
            description="Decompose design into implementation tasks, file breakdown, and function specs. Output markdown task plan.",
            expected_output="Markdown task plan with list of python files to create.",
            agent=self.agents["planner"]
        )

        crew_stage1 = Crew(
            agents=[self.agents["requirements_analyst"], self.agents["srs_author"], self.agents["architect"], self.agents["planner"]],
            tasks=[req_task, srs_task, design_task, plan_task],
            process=Process.sequential
        )

        crew_stage1.kickoff()
        
        req_out = req_task.output.raw if hasattr(req_task.output, 'raw') else str(req_task.output)
        srs_out = srs_task.output.raw if hasattr(srs_task.output, 'raw') else str(srs_task.output)
        design_out = design_task.output.raw if hasattr(design_task.output, 'raw') else str(design_task.output)
        plan_out = plan_task.output.raw if hasattr(plan_task.output, 'raw') else str(plan_task.output)

        store.save_artifact("Requirements.md", req_out)
        store.save_artifact("SRS.md", srs_out)
        store.save_artifact("Design.md", design_out)
        store.save_artifact("Tasks.md", plan_out)

        # Step 5: Code Generation Task
        main_mod_name = project_name.lower().replace('-', '_')
        main_py_name = f"{main_mod_name}.py"
        code_task = Task(
            description=(
                f"Write clean, modular Python functions in file `{main_py_name}` based on design spec.\n"
                f"Define functions: `add(a, b)`, `subtract(a, b)`, `multiply(a, b)`, `divide(a, b)`.\n"
                f"IMPORTANT: `divide(a, b)` MUST raise `ValueError('Cannot divide by zero')` when b == 0.\n"
                f"Do not ask for interactive user input. Return values directly.\n"
                f"Output ONLY valid Python code inside a single ```python code block."
            ),
            expected_output=f"Working Python code for {main_py_name}",
            agent=self.agents["coder"]
        )

        # Step 6: Testing Task
        test_py_name = f"test_{main_py_name}"
        test_task = Task(
            description=(
                f"Write self-contained pytest unit tests for `{main_py_name}` in file `{test_py_name}`.\n"
                f"MUST START WITH: `import pytest` and `from {main_mod_name} import add, subtract, multiply, divide`.\n"
                f"Check division by zero using `with pytest.raises(ValueError): divide(5, 0)` (b MUST be 0).\n"
                f"CRITICAL: Division by zero means b=0 (e.g., divide(5, 0)). NEVER test divide(0, 5) for division by zero.\n"
                f"DO NOT try to open external files or use sys.stdin.\n"
                f"Output ONLY valid Python pytest code inside a single ```python code block."
            ),
            expected_output=f"Working pytest code for {test_py_name}",
            agent=self.agents["tester"]
        )

        # Step 7: Documentation Task
        doc_task = Task(
            description=f"Write a complete README.md user documentation for project `{project_name}` based on design and API usage.",
            expected_output="Markdown README documentation.",
            agent=self.agents["doc_writer"]
        )

        crew_stage2 = Crew(
            agents=[self.agents["coder"], self.agents["tester"], self.agents["doc_writer"]],
            tasks=[code_task, test_task, doc_task],
            process=Process.sequential
        )

        crew_stage2.kickoff()

        code_out = extract_code_block(code_task.output.raw if hasattr(code_task.output, 'raw') else str(code_task.output), "python")
        test_out = extract_code_block(test_task.output.raw if hasattr(test_task.output, 'raw') else str(test_task.output), "python")
        if "import pytest" not in test_out:
            test_out = "import pytest\n" + test_out
        doc_out = doc_task.output.raw if hasattr(doc_task.output, 'raw') else str(doc_task.output)

        # Save artifacts
        store.save_artifact(main_py_name, code_out, is_code=True)
        store.save_artifact(test_py_name, test_out, is_code=True)
        store.save_artifact("README.md", doc_out, is_code=False)

        # Git commit initial version
        git_mgr.commit_all("Initial automated SDLC project generation")

        # Step 8: Pytest execution & agentic debugging loop
        runner = PytestRunner(store.project_dir)
        test_res = runner.run_tests()
        
        debug_attempts = 0
        max_attempts = 3

        while not test_res.get("passed", False) and debug_attempts < max_attempts:
            debug_attempts += 1
            print(f"\n[Agentic Debug Loop] Initial Build Attempt #{debug_attempts}...")
            error_trace = test_res.get("output", "")
            
            debug_task = Task(
                description=(
                    f"Pytest failed for `{main_py_name}`.\n"
                    f"Error Trace Output:\n{error_trace}\n\n"
                    f"Current `{main_py_name}` source code:\n{code_out}\n\n"
                    f"Current `{test_py_name}` test code:\n{test_out}\n\n"
                    f"Fix the code and/or test file so that `pytest` passes cleanly.\n"
                    f"CRITICAL: Division by zero means b=0 (e.g. divide(5, 0)). Never test divide(0, 5) for division by zero.\n"
                    f"Make sure test assertions have mathematically correct expected values!\n"
                    f"Output EXACTLY TWO ```python code blocks:\n"
                    f"Block 1: Full updated `{main_py_name}` Python source code\n"
                    f"Block 2: Full updated `{test_py_name}` Pytest test code"
                ),
                expected_output=f"Fixed Python source code and test code for `{main_py_name}`",
                agent=self.agents["debugger"]
            )
            
            crew_debug = Crew(agents=[self.agents["debugger"]], tasks=[debug_task])
            crew_debug.kickoff()
            
            raw_debug_out = debug_task.output.raw if hasattr(debug_task.output, 'raw') else str(debug_task.output)
            fixed_code, fixed_test = extract_named_code_blocks(raw_debug_out)

            if fixed_code:
                code_out = fixed_code
                store.save_artifact(main_py_name, code_out, is_code=True)
            if fixed_test:
                test_out = fixed_test
                if "import pytest" not in test_out:
                    test_out = "import pytest\n" + test_out
                store.save_artifact(test_py_name, test_out, is_code=True)

            git_mgr.commit_all(f"Agentic Debug Fix attempt #{debug_attempts}")
            test_res = runner.run_tests()

        # Step 9: Build Traceability Graph
        graph = TraceabilityGraph()
        req_lines = [l for l in req_out.split("\n") if l.strip()]
        graph.build_default_project_graph(req_lines, [main_py_name], [test_py_name])
        store.save_traceability_graph(graph)

        # Save Metadata
        metadata = {
            "project_name": project_name,
            "requirements": requirements_text,
            "main_file": main_py_name,
            "test_file": test_py_name,
            "test_status": "PASSED" if test_res.get("passed") else "FAILED",
            "debug_attempts": debug_attempts
        }
        store.save_metadata(metadata)

        return {
            "project_name": project_name,
            "status": "COMPLETED",
            "test_results": test_res,
            "debug_attempts": debug_attempts,
            "files_created": [main_py_name, test_py_name, "Requirements.md", "SRS.md", "Design.md", "Tasks.md", "README.md"]
        }

    def run_incremental_requirement_change(self, project_name: str, updated_requirements_text: str) -> Dict[str, Any]:
        """
        Executes incremental requirement change update across all artifacts (Requirements, SRS, Design, Code, Tests, Docs).
        """
        store = ProjectStore(project_name)
        git_mgr = GitManager(store.project_dir)
        old_meta = store.load_metadata()
        old_reqs = old_meta.get("requirements", "")

        main_mod_name = project_name.lower().replace('-', '_')
        main_py_name = old_meta.get("main_file", f"{main_mod_name}.py")
        test_py_name = old_meta.get("test_file", f"test_{main_py_name}")

        # 1. Change detection & impact analysis
        graph = store.load_traceability_graph()
        change_report = graph.detect_changes(old_reqs, updated_requirements_text)
        changed_ids = ["REQ_1"] if change_report["is_changed"] else []
        impact_report = graph.analyze_impact(changed_ids)

        existing_reqs = store.read_artifact("Requirements.md") or ""
        existing_srs = store.read_artifact("SRS.md") or ""
        existing_design = store.read_artifact("Design.md") or ""
        existing_code = store.read_artifact(main_py_name, is_code=True) or ""
        existing_test = store.read_artifact(test_py_name, is_code=True) or ""
        existing_doc = store.read_artifact("README.md") or ""

        # Requirements Update Task
        req_update_task = Task(
            description=f"Update functional requirements document (Requirements.md) based on new requirements:\n{updated_requirements_text}\nExisting Requirements:\n{existing_reqs}",
            expected_output="Updated numbered list of functional & non-functional requirements.",
            agent=self.agents["requirements_analyst"]
        )

        # SRS Update Task
        srs_update_task = Task(
            description=f"Update SRS document (SRS.md) incrementally for this requirement change:\n{change_report['summary']}\nNew Requirements:\n{updated_requirements_text}\nExisting SRS:\n{existing_srs}",
            expected_output="Updated SRS Markdown document.",
            agent=self.agents["srs_author"]
        )

        # Design Update Task
        design_update_task = Task(
            description=f"Update architecture and component design spec in Design.md for the requirement change:\n{change_report['summary']}\nNew Requirements:\n{updated_requirements_text}\nExisting Design:\n{existing_design}",
            expected_output="Updated Architecture & Design Markdown document.",
            agent=self.agents["architect"]
        )

        # Code Update Task
        code_update_task = Task(
            description=(
                f"Modify `{main_py_name}` to implement new/updated requirements while preserving existing functionality.\n"
                f"Requirement Delta:\n{change_report['summary']}\nNew Requirements:\n{updated_requirements_text}\n"
                f"Existing Code:\n{existing_code}\n"
                f"Output ONLY updated Python code in a single ```python block."
            ),
            expected_output="Updated Python source code.",
            agent=self.agents["coder"]
        )

        # Test Update Task
        test_update_task = Task(
            description=(
                f"Update pytest unit tests in `{test_py_name}` to cover updated requirements while keeping existing tests.\n"
                f"MUST START WITH: `import pytest` and `from {main_mod_name} import ...`.\n"
                f"Ensure math test assertions are correct: (-1)**2 is 1, 0**5 is 0, base**0 is 1.\n"
                f"Existing Test Code:\n{existing_test}\n"
                f"Output ONLY updated pytest code in a single ```python block."
            ),
            expected_output="Updated pytest unit test code.",
            agent=self.agents["tester"]
        )

        # Documentation Update Task
        doc_update_task = Task(
            description=f"Update README.md user documentation to reflect newly added/modified features.\nExisting README:\n{existing_doc}",
            expected_output="Updated Markdown README documentation.",
            agent=self.agents["doc_writer"]
        )

        crew_update = Crew(
            agents=[self.agents["requirements_analyst"], self.agents["srs_author"], self.agents["architect"], self.agents["coder"], self.agents["tester"], self.agents["doc_writer"]],
            tasks=[req_update_task, srs_update_task, design_update_task, code_update_task, test_update_task, doc_update_task],
            process=Process.sequential
        )

        crew_update.kickoff()

        updated_req = req_update_task.output.raw if hasattr(req_update_task.output, 'raw') else str(req_update_task.output)
        updated_srs = srs_update_task.output.raw if hasattr(srs_update_task.output, 'raw') else str(srs_update_task.output)
        updated_design = design_update_task.output.raw if hasattr(design_update_task.output, 'raw') else str(design_update_task.output)
        updated_code = extract_code_block(code_update_task.output.raw if hasattr(code_update_task.output, 'raw') else str(code_update_task.output), "python")
        updated_test = extract_code_block(test_update_task.output.raw if hasattr(test_update_task.output, 'raw') else str(test_update_task.output), "python")
        updated_doc = doc_update_task.output.raw if hasattr(doc_update_task.output, 'raw') else str(doc_update_task.output)

        if "import pytest" not in updated_test:
            updated_test = "import pytest\n" + updated_test

        store.save_artifact("Requirements.md", updated_req)
        store.save_artifact("SRS.md", updated_srs)
        store.save_artifact("Design.md", updated_design)
        store.save_artifact("README.md", updated_doc)
        store.save_artifact("Requirement_Delta_Report.md", json.dumps(change_report, indent=2))
        store.save_artifact(main_py_name, updated_code, is_code=True)
        store.save_artifact(test_py_name, updated_test, is_code=True)

        git_mgr.commit_all(f"Requirement Change Update: {change_report['summary']}")

        # 3. Test execution & debugging loop
        runner = PytestRunner(store.project_dir)
        test_res = runner.run_tests()
        
        debug_attempts = 0
        while not test_res.get("passed", False) and debug_attempts < 3:
            debug_attempts += 1
            print(f"\n[Agentic Debug Loop] Requirement Change Attempt #{debug_attempts}...")
            error_trace = test_res.get("output", "")
            
            debug_task = Task(
                description=(
                    f"Pytest failed after requirement change update.\n"
                    f"Error Trace Output:\n{error_trace}\n\n"
                    f"Current `{main_py_name}` source code:\n{updated_code}\n\n"
                    f"Current `{test_py_name}` test code:\n{updated_test}\n\n"
                    f"Fix the code and/or test file so that `pytest` passes cleanly.\n"
                    f"CRITICAL: Division by zero means b=0 (e.g. divide(5, 0)). Never test divide(0, 5) for division by zero.\n"
                    f"NOTE MATH: (-1)**2 is 1 (positive 1), 0**5 is 0, base**0 is 1. Fix any invalid test assertions!\n"
                    f"Output EXACTLY TWO ```python code blocks:\n"
                    f"Block 1: Full updated `{main_py_name}` Python source code\n"
                    f"Block 2: Full updated `{test_py_name}` Pytest test code"
                ),
                expected_output="Fixed Python source code and test code.",
                agent=self.agents["debugger"]
            )
            crew_debug = Crew(agents=[self.agents["debugger"]], tasks=[debug_task])
            crew_debug.kickoff()
            
            raw_debug_out = debug_task.output.raw if hasattr(debug_task.output, 'raw') else str(debug_task.output)
            fixed_code, fixed_test = extract_named_code_blocks(raw_debug_out)

            if fixed_code:
                updated_code = fixed_code
                store.save_artifact(main_py_name, updated_code, is_code=True)
            if fixed_test:
                updated_test = fixed_test
                if "import pytest" not in updated_test:
                    updated_test = "import pytest\n" + updated_test
                store.save_artifact(test_py_name, updated_test, is_code=True)

            git_mgr.commit_all(f"Requirement Change Debug Fix #{debug_attempts}")
            test_res = runner.run_tests()

        # Update metadata
        old_meta["requirements"] = updated_requirements_text
        old_meta["test_status"] = "PASSED" if test_res.get("passed") else "FAILED"
        old_meta["last_change_report"] = change_report
        store.save_metadata(old_meta)

        return {
            "project_name": project_name,
            "status": "INCREMENTAL_UPDATE_COMPLETED",
            "change_report": change_report,
            "impact_report": impact_report,
            "test_results": test_res,
            "debug_attempts": debug_attempts
        }
