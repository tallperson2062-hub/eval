# Block 1: Full updated `task_manager.py` Python source code
import math

class TaskManager:
    def __init__(self):
        self.tasks = {}

    def add_task(self, task_id, duration):
        if task_id in self.tasks:
            raise ValueError(f"Task ID {task_id} already exists")
        self.tasks[task_id] = duration

    def update_task(self, task_id, new_duration):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        self.tasks[task_id] = new_duration

    def delete_task(self, task_id):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        del self.tasks[task_id]

    def get_task_duration(self, task_id):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        return self.tasks[task_id]