# Block 1: Full updated `task_manager.py` Python source code
import math

class TaskManager:
    def __init__(self):
        self.tasks = {}

    def add_task(self, task_id, duration):
        if task_id in self.tasks:
            raise ValueError(f"Task ID {task_id} already exists")
        self.tasks[task_id] = duration

    def update_task(self, task_id, new_duration):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        self.tasks[task_id] = new_duration

    def delete_task(self, task_id):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        del self.tasks[task_id]

    def get_task_duration(self, task_id):
        if task_id not in self.tasks:
            raise ValueError(f"Task ID {task_id} does not exist")
        return self.tasks[task_id]

# Block 2: Full updated `test_task_manager.py` Pytest test code
import pytest
from task_manager import TaskManager

def test_add_task():
    manager = TaskManager()
    manager.add_task("task1", 10)
    assert manager.get_task_duration("task1") == 10

def test_update_task():
    manager = TaskManager()
    manager.add_task("task1", 10)
    manager.update_task("task1", 20)
    assert manager.get_task_duration("task1") == 20

def test_delete_task():
    manager = TaskManager()
    manager.add_task("task1", 10)
    manager.delete_task("task1")
    with pytest.raises(ValueError):
        manager.get_task_duration("task1")

def test_get_task_duration_nonexistent_task():
    manager = TaskManager()
    with pytest.raises(ValueError):
        manager.get_task_duration("nonexistent_task")

def test_division_by_zero():
    # Fix the division by zero error
    def divide(a, b):
        if b == 0:
            raise ZeroDivisionError(f"Cannot divide by zero")
        return a / b

    with pytest.raises(ZeroDivisionError):
        divide(5, 0)

def test_invalid_test_assertion():
    # This test will fail because the assertion is invalid
    assert False and True

def test_invalid_test_assertion_2():
    # This test will pass because the assertion is valid
    assert False or True

def test_task_duration_is_zero_for_empty_tasks():
    manager = TaskManager()
    assert manager.get_task_duration("nonexistent_task") == 0

def test_task_duration_is_zero_for_deleted_tasks():
    manager = TaskManager()
    manager.add_task("task1", 10)
    manager.delete_task("task1")
    assert manager.get_task_duration("task1") == 0