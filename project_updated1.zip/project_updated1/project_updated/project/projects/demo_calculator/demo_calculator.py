# Block 1: Full updated `demo_calculator.py` Python source code
import math

def add(a, b):
    """
    Adds two numbers together.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("Both inputs must be numbers")
    return a + b

def subtract(a, b):
    """
    Subtracts two numbers together.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference of a and b.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("Both inputs must be numbers")
    return a - b

def multiply(a, b):
    """
    Multiplies two numbers together.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("Both inputs must be numbers")
    return a * b

def divide(a, b):
    """
    Divides two numbers together.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If the divisor is zero.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("Both inputs must be numbers")
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def main():
    print("Simple Calculator")
    while True:
        try:
            num1 = float(input("Enter the first number: "))
            operator = input("Enter the operator (+, -, *, /): ")
            num2 = float(input("Enter the second number: "))

            if operator == "+":
                result = add(num1, num2)
            elif operator == "-":
                result = subtract(num1, num2)
            elif operator == "*":
                result = multiply(num1, num2)
            elif operator == "/":
                result = divide(num1, num2)
            else:
                print("Invalid operator. Please try again.")
                continue

            print(f"{num1} {operator} {num2} = {result}")

        except (TypeError, ValueError) as e:
            print(str(e))

if __name__ == "__main__":
    main()