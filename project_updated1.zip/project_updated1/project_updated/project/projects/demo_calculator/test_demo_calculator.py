# Block 2: Full updated `test_demo_calculator.py` Pytest test code
import pytest
from demo_calculator import add, subtract, multiply, divide

def test_add():
    assert add(5, 3) == 8
    with pytest.raises(TypeError):
        add("a", 3)
    with pytest.raises(TypeError):
        add(3, "b")

def test_subtract():
    assert subtract(5, 3) == 2
    with pytest.raises(TypeError):
        subtract("a", 3)
    with pytest.raises(TypeError):
        subtract(3, "b")
    assert subtract(0, 3) == -3

def test_multiply():
    assert multiply(5, 3) == 15
    with pytest.raises(TypeError):
        multiply("a", 3)
    with pytest.raises(TypeError):
        multiply(3, "b")

def test_divide():
    assert divide(6, 2) == 3
    with pytest.raises(ValueError):
        divide(6, 0)

def test_divide_by_zero():
    with pytest.raises(ValueError):
        divide(5, 0)
    with pytest.raises(TypeError):
        divide("a", 0)

# Added a new test case to cover the division by zero scenario
def test_division_by_zero():
    with pytest.raises(ValueError):
        divide(6, 0)

# Removed the duplicate test case for invalid operator
def test_invalid_operator():
    with pytest.raises(TypeError):
        add(1, "b")