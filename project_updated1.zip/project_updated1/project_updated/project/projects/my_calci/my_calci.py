def add(a, b):
    """
    Returns the sum of two numbers.

    Args:
        a (float): The first number.
        b (float): The second number.

    Returns:
        float: The sum of a and b.
    """
    return a + b


def subtract(a, b):
    """
    Returns the difference between two numbers.

    Args:
        a (float): The first number.
        b (float): The second number.

    Returns:
        float: The difference between a and b.
    """
    return a - b


def multiply(a, b):
    """
    Returns the product of two numbers.

    Args:
        a (float): The first number.
        b (float): The second number.

    Returns:
        float: The product of a and b.

    Raises:
        TypeError: If either input is not a number.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError('Both inputs must be numbers')
    return a * b


def divide(a, b):
    """
    Returns the quotient of two numbers.

    Args:
        a (float): The dividend.
        b (float): The divisor.

    Returns:
        float: The quotient of a and b.

    Raises:
        ValueError: If b is zero.
        TypeError: If either input is not a number.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError('Both inputs must be numbers')
    if b == 0:
        raise ValueError('Cannot divide by zero')
    return a / b


def power(base, exponent):
    """
    Returns the result of raising base to the power of exponent.

    Args:
        base (float): The base number.
        exponent (int): The exponent.

    Returns:
        float: The result of base raised to the power of exponent.

    Raises:
        TypeError: If either input is not a number.
    """
    if not isinstance(base, (int, float)) or not isinstance(exponent, int):
        raise TypeError('Base must be a number and exponent must be an integer')
    return base ** exponent


def calculator():
    while True:
        print("\nCalculator Menu:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Power")
        print("6. Quit")

        choice = input("Enter your choice: ")

        if choice == "1":
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
            print(f"{a} + {b} = {add(a, b)}")
        elif choice == "2":
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
            print(f"{a} - {b} = {subtract(a, b)}")
        elif choice == "3":
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
            print(f"{a} * {b} = {multiply(a, b)}")
        elif choice == "4":
            try:
                a = float(input("Enter dividend: "))
                b = float(input("Enter divisor: "))
                if b == 0:
                    raise ValueError
                print(f"{a} / {b} = {divide(a, b)}")
            except ValueError as e:
                print(e)
        elif choice == "5":
            try:
                base = float(input("Enter base number: "))
                exponent = int(input("Enter exponent: "))
                print(f"{base} ^ {exponent} = {power(base, exponent)}")
            except TypeError as e:
                print(e)
        elif choice == "6":
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    calculator()