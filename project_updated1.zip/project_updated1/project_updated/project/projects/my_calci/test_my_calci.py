import pytest
from my_calci import add, subtract, multiply, divide, power


def test_add():
    """Test the addition function."""
    assert add(5, 3) == 8
    assert add(-2, 4) == 2
    with pytest.raises(TypeError):
        add('a', 3)


def test_subtract():
    """Test the subtraction function."""
    assert subtract(5, 3) == 2
    assert subtract(-2, 4) == -6
    with pytest.raises(TypeError):
        subtract('a', 3)


def test_multiply():
    """Test the multiplication function."""
    assert multiply(5, 3) == 15
    assert multiply(-2, 4) == -8
    with pytest.raises(TypeError):
        multiply('a', 3)


def test_divide():
    """Test the division function."""
    assert divide(5, 3) == 1.6666666666666667
    assert divide(-2, 4) == -0.5
    with pytest.raises(ValueError):
        divide(5, 0)
    with pytest.raises(TypeError):
        divide('a', 3)


def test_divide_invalid_input():
    """Test the division function with invalid input."""
    with pytest.raises(TypeError):
        divide(5, 'a')
    with pytest.raises(TypeError):
        divide('a', 5)


def test_power():
    """Test the power function."""
    assert power(2, 3) == 8
    assert power(-1, 2) == 1
    assert power(0, 5) == 0
    with pytest.raises(TypeError):
        power('a', 3)
    with pytest.raises(TypeError):
        power(3, 'c')


def test_power_invalid_input():
    """Test the power function with invalid input."""
    with pytest.raises(TypeError):
        power('a', 2)


def test_add_and_subtract():
    """Test the addition and subtraction functions."""
    assert add(-1, -1) == -2
    assert subtract(5, 3) == 2


def test_multiply_and_divide():
    """Test the multiplication and division functions."""
    assert multiply(4, 6) == 24
    assert divide(12, 4) == 3


def test_power_with_zero_base():
    """Test the power function with zero base."""
    assert power(0, 5) == 0


def test_power_with_negative_number():
    """Test the power function with negative number."""
    assert power(-1, 2) == 1