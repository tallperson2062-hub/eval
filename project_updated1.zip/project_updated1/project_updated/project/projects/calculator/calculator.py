def add(a, b):
    """
    Returns the sum of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    return a + b


def subtract(a, b):
    """
    Returns the difference between two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    return a - b


def multiply(a, b):
    """
    Returns the product of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    return a * b


def divide(a, b):
    """
    Returns the quotient of two numbers.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If b is zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def validate_input_types(func, a, b):
    """
    Validate the input types for a function.
    
    Args:
        func (function): The function to be validated.
        a: The first argument.
        b: The second argument.
    
    Returns:
        bool: True if the input types are valid, False otherwise.
    """
    return isinstance(a, (int, float)) and isinstance(b, (int, float))


def add_validated(a, b):
    """
    Add two numbers with validated input types.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    if not validate_input_types(add, a, b):
        raise TypeError("Invalid input type")
    return add(a, b)


def subtract_validated(a, b):
    """
    Subtract two numbers with validated input types.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    if not validate_input_types(subtract, a, b):
        raise TypeError("Invalid input type")
    return subtract(a, b)


def multiply_validated(a, b):
    """
    Multiply two numbers with validated input types.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    if not validate_input_types(multiply, a, b):
        raise TypeError("Invalid input type")
    return multiply(a, b)


def divide_validated(a, b):
    """
    Divide two numbers with validated input types.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If b is zero.
    """
    if not validate_input_types(divide, a, b):
        raise TypeError("Invalid input type")
    return divide(a, b)