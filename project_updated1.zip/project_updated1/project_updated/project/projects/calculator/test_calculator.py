import pytest
from calculator import add_validated, subtract_validated, multiply_validated, divide_validated

def test_add():
    """Test the addition function"""
    assert add_validated(5, 3) == 8
    assert add_validated(-2, 4) == -2


def test_subtract():
    """Test the subtraction function"""
    assert subtract_validated(9, 4) == 5
    assert subtract_validated(-1, 2) == -3


def test_multiply():
    """Test the multiplication function"""
    assert multiply_validated(6, 7) == 42
    assert multiply_validated(-3, 2) == -6


def test_divide():
    """Test the division function"""
    assert divide_validated(10, 2) == 5.0
    assert divide_validated(-4, 2) == -2.0


def test_division_by_zero():
    """Test that division by zero raises a ValueError"""
    with pytest.raises(ValueError):
        divide_validated(5, 0)
    # Test for division by zero in the other direction
    with pytest.raises(ValueError):
        divide_validated(-10, 0)


def test_invalid_input_types():
    """Test that the functions raise TypeError for invalid input types"""
    with pytest.raises(TypeError):
        add_validated("a", 3)
    with pytest.raises(TypeError):
        subtract_validated("a", 3)
    with pytest.raises(TypeError):
        multiply_validated("a", 3)
    with pytest.raises(TypeError):
        divide_validated("a", 3)


def test_divide_negative_numbers():
    """Test that the division function works with negative numbers"""
    assert divide_validated(-10, -2) == 5.0