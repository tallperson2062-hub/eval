def add(a, b):
    """
    Returns the sum of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    return a + b


def subtract(a, b):
    """
    Returns the difference between two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    return a - b


def multiply(a, b):
    """
    Returns the product of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    return a * b


def divide(a, b):
    """
    Returns the quotient of two numbers.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If b is zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def power(base, exponent):
    """
    Returns the result of raising base to the power of exponent.
    
    Args:
        base (float): The base number.
        exponent (int or float): The exponent value.
    
    Returns:
        float: The result of base raised to the power of exponent.
    """
    return base ** exponent


def main():
    while True:
        print("\nCalculator Menu:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Power")
        print("6. Quit")

        choice = input("Choose an operation (1-6): ")

        if choice == "1":
            a = float(input("Enter the first number: "))
            b = float(input("Enter the second number: "))
            result = add(a, b)
            print(f"{a} + {b} = {result}")
        elif choice == "2":
            a = float(input("Enter the first number: "))
            b = float(input("Enter the second number: "))
            result = subtract(a, b)
            print(f"{a} - {b} = {result}")
        elif choice == "3":
            a = float(input("Enter the first number: "))
            b = float(input("Enter the second number: "))
            result = multiply(a, b)
            print(f"{a} * {b} = {result}")
        elif choice == "4":
            try:
                a = float(input("Enter the dividend: "))
                b = float(input("Enter the divisor: "))
                if b == 0:
                    raise ValueError
                result = divide(a, b)
                print(f"{a} / {b} = {result}")
            except ValueError as e:
                print(e)
        elif choice == "5":
            try:
                base = float(input("Enter the base number: "))
                exponent = int(input("Enter the exponent value: "))
                result = power(base, exponent)
                print(f"{base} ^ {exponent} = {result}")
            except ValueError as e:
                print(e)
        elif choice == "6":
            break
        else:
            print("Invalid choice. Please choose a valid operation.")


if __name__ == "__main__":
    main()