# Block 1: Full updated `demo_calculator.py` Python source code

def add(a, b):
    """
    Returns the sum of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    return a + b


def subtract(a, b):
    """
    Returns the difference between two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    return a - b


def multiply(a, b):
    """
    Returns the product of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    return a * b


def divide(a, b):
    """
    Returns the quotient of two numbers.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If the divisor is zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def power(base, exponent):
    """
    Returns base raised to the power of exponent (base ** exponent).
    
    Args:
        base (float): The base number.
        exponent (int): The exponent.
    
    Returns:
        float: The result of base raised to the power of exponent.
    
    Raises:
        TypeError: If either base or exponent is not a number.
    """
    if not isinstance(base, (int, float)) or not isinstance(exponent, int):
        raise TypeError("Both base and exponent must be numbers")
    return base ** exponent


if __name__ == "__main__":
    print("Calculator Module")
    print("-----------------")

    while True:
        print("\nOperations:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Power")
        print("6. Quit")

        choice = input("Choose an operation: ")

        if choice == "6":
            break

        elif choice in ["1", "2", "3", "4"]:
            try:
                num1 = float(input("Enter the first number: "))
                num2 = float(input("Enter the second number: "))

                if choice == "1":
                    print(f"{num1} + {num2} = {add(num1, num2)}")
                elif choice == "2":
                    print(f"{num1} - {num2} = {subtract(num1, num2)}")
                elif choice == "3":
                    print(f"{num1} * {num2} = {multiply(num1, num2)}")
                elif choice == "4":
                    try:
                        print(f"{num1} / {num2} = {divide(num1, num2)}")
                    except ValueError as e:
                        print(e)
                else:
                    raise ValueError("Invalid operation")

            except ValueError as e:
                print(e)

        else:
            raise ValueError("Invalid choice")


# Block 2: Full updated `test_demo_calculator.py` Pytest test code

import pytest
from demo_calculator import add, subtract, multiply, divide, power


def test_add():
    """Test the addition function."""
    assert add(5, 3) == 8
    assert add(-2, 4) == 2
    assert add(0, 0) == 0


def test_subtract():
    """Test the subtraction function."""
    assert subtract(5, 3) == 2
    assert subtract(-2, 4) == -6
    assert subtract(0, 0) == 0


def test_multiply():
    """Test the multiplication function."""
    assert multiply(5, 3) == 15
    assert multiply(-2, 4) == -8
    assert multiply(0, 0) == 0


def test_divide():
    """Test the division function."""
    assert divide(5, 3) == 1.6666666666666667
    assert divide(-2, 4) == -0.5
    assert divide(0, 10) == 0

    with pytest.raises(ValueError):
        divide(5, 0)

    def test_divide_invalid_input():
        """Test the division function with invalid input."""
        with pytest.raises(TypeError):
            divide("a", 3)


def test_power():
    """Test the power function."""
    assert power(-1, 2) == 1
    assert power(0, 5) == 0
    assert power(2, 0) == 1

    def test_power_invalid_input():
        """Test the power function with invalid input."""
        with pytest.raises(TypeError):
            power("a", 3)

    def test_power_non_integer_exponent():
        """Test the power function with a non-integer exponent."""
        with pytest.raises(TypeError):
            power(2, 3.5)


def test_divide_by_zero():
    """Test the division function by zero."""
    with pytest.raises(ValueError):
        divide(1, 0)

    def test_power_by_zero():
        """Test the power function by zero."""
        assert power(2, 0) == 1


def test_add_and_subtract():
    """Test the addition and subtraction functions."""
    assert add(-5, -3) == -8
    assert subtract(-5, -3) == 2
    assert subtract(-5, -3) + add(-5, -3) == 0

def test_multiply_and_divide():
    """Test the multiplication and division functions."""
    assert multiply(5, divide(10, 2)) == 25
    assert divide(multiply(5, 2), 2) == 5


def test_power_and_addition():
    """Test the power function and addition function."""
    # Fix invalid assertion: add(power(2, 3), power(3, 4)) should be 89, not 97
    assert add(power(2, 3), power(3, 4)) == 89

def test_power_and_addition_with_zero():
    """Test the power function and addition function with zero."""
    # Fix invalid assertion: add(power(0, 5), power(0, 6)) should be 0, not 97
    assert add(power(0, 5), power(0, 6)) == 0