def add(a, b):
    """
    Returns the sum of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The sum of a and b.
    """
    return a + b


def subtract(a, b):
    """
    Returns the difference between two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The difference between a and b.
    """
    return a - b


def multiply(a, b):
    """
    Returns the product of two numbers.
    
    Args:
        a (float): The first number.
        b (float): The second number.
    
    Returns:
        float: The product of a and b.
    """
    return a * b


def divide(a, b):
    """
    Returns the quotient of two numbers.
    
    Args:
        a (float): The dividend.
        b (float): The divisor.
    
    Returns:
        float: The quotient of a and b.
    
    Raises:
        ValueError: If the divisor is zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def power(base, exponent):
    """
    Returns base raised to the power of exponent (base ** exponent).
    
    Args:
        base (float): The base number.
        exponent (int): The exponent.
    
    Returns:
        float: The result of base raised to the power of exponent.
    
    Raises:
        TypeError: If either base or exponent is not a number.
    """
    if not isinstance(base, (int, float)) or not isinstance(exponent, int):
        raise TypeError("Both base and exponent must be numbers")
    return base ** exponent


if __name__ == "__main__":
    print("Calculator Module")
    print("-----------------")

    while True:
        print("\nOperations:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Power")
        print("6. Quit")

        choice = input("Choose an operation: ")

        if choice == "6":
            break

        elif choice in ["1", "2", "3", "4"]:
            try:
                num1 = float(input("Enter the first number: "))
                num2 = float(input("Enter the second number: "))

                if choice == "1":
                    print(f"{num1} + {num2} = {add(num1, num2)}")
                elif choice == "2":
                    print(f"{num1} - {num2} = {subtract(num1, num2)}")
                elif choice == "3":
                    print(f"{num1} * {num2} = {multiply(num1, num2)}")
                elif choice == "4":
                    try:
                        print(f"{num1} / {num2} = {divide(num1, num2)}")
                    except ValueError as e:
                        print(e)
                else:
                    raise ValueError("Invalid operation")

            except ValueError as e:
                print(e)

        else:
            raise ValueError("Invalid choice")