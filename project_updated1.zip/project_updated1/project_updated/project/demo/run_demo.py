import os
import sys
import json
import time

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from config.settings import MODEL_NAME, OLLAMA_BASE_URL
from agents.sdlc_crew import SDLCOrchestrator
from core.project_store import ProjectStore
from core.runner import PytestRunner
from evaluation import print_report, run_with_evaluation

def run_end_to_end_demo():
    print("==========================================================================")
    print("        ⚡ EVOFORGE AGENTIC SDLC PLATFORM - DEMONSTRATION RUN ⚡          ")
    print("==========================================================================")
    print(f"[*] Local LLM Model: {MODEL_NAME}")
    print(f"[*] Ollama Base URL: {OLLAMA_BASE_URL}\n")

    project_name = "demo_calculator"
    orchestrator = SDLCOrchestrator()

    # Initial Requirements
    initial_reqs = (
        "Build a Python module for a calculator system. "
        "It must support four core functions:\n"
        "1. add(a, b): Returns the sum of a and b.\n"
        "2. subtract(a, b): Returns a minus b.\n"
        "3. multiply(a, b): Returns product of a and b.\n"
        "4. divide(a, b): Returns quotient of a divided by b. Raise ValueError if b is 0.\n"
    )

    print("==========================================================================")
    print("PHASE 1: INITIAL AUTOMATED SDLC GENERATION")
    print("==========================================================================")
    print(f"[*] Input Client Requirements:\n{initial_reqs}")

    start_time = time.time()
    res1, eval1 = run_with_evaluation(orchestrator.run_initial_sdlc_pipeline, "initial", project_name, initial_reqs)
    print(f"\n[+] Initial SDLC Generation Completed in {round(time.time() - start_time, 2)}s!")
    print(f"[+] Files Generated: {res1['files_created']}")
    print(f"[+] Pytest Initial Status: {res1['test_results'].get('passed')}")

    store = ProjectStore(project_name)
    runner = PytestRunner(store.project_dir)
    test_run_1 = runner.run_tests()
    print("\n--- Initial Pytest Execution Report ---")
    print(test_run_1["output"])
    assert test_run_1["passed"], "Initial pytest suite failed!"
    print_report(eval1)  # AI agent evaluation of phase 1 (6 metrics, computed from the real run)

    # Requirement Change Update
    print("\n==========================================================================")
    print("PHASE 2: AUTOMATED REQUIREMENT CHANGE & IMPACT ANALYSIS")
    print("==========================================================================")

    updated_reqs = (
        initial_reqs +
        "5. power(base, exponent): Returns base raised to the power of exponent (base ** exponent).\n"
    )
    print(f"[*] Client Requirement Delta Added: power(base, exponent)\n")

    start_time_change = time.time()
    res2, eval2 = run_with_evaluation(orchestrator.run_incremental_requirement_change, "change", project_name, updated_reqs)
    print(f"\n[+] Incremental Requirement Update Completed in {round(time.time() - start_time_change, 2)}s!")
    print("\n--- Requirement Delta Report ---")
    print(json.dumps(res2["change_report"], indent=2))
    print("\n--- Downstream Impact Analysis ---")
    print(json.dumps(res2["impact_report"], indent=2))

    test_run_2 = runner.run_tests()
    print("\n--- Post-Change Pytest Execution Report ---")
    print(test_run_2["output"])
    assert test_run_2["passed"], "Post-requirement-change pytest suite failed!"
    print_report(eval2)  # AI agent evaluation of phase 2 (6 metrics, computed from the real run)

    print("\n==========================================================================")
    print("🎉 END-TO-END DEMONSTRATION SUCCESSFUL! ALL TESTS PASSED!")
    print("==========================================================================")

if __name__ == "__main__":
    run_end_to_end_demo()
