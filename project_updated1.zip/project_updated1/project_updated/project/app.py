import os
import json
import streamlit as st
from config.settings import MODEL_NAME, OLLAMA_BASE_URL, PROJECTS_DIR, REPORTS_DIR
from agents.sdlc_crew import SDLCOrchestrator
from core.project_store import ProjectStore
from core.runner import PytestRunner
from core.git_manager import GitManager
from evaluation import evaluate_latest_trace, run_with_evaluation
from evaluation.evaluator import eval_dir

st.set_page_config(
    page_title="EvoForge - Agentic SDLC Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for rich aesthetics
st.markdown("""
<style>
    .main-title {
        font-size: 2.5rem;
        font-weight: 800;
        background: linear-gradient(90deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .sub-title {
        font-size: 1.1rem;
        color: #9CA3AF;
        margin-bottom: 2rem;
    }
    .stCard {
        background-color: #1F2937;
        padding: 1.5rem;
        border-radius: 0.75rem;
        border: 1px solid #374151;
        margin-bottom: 1rem;
    }
    .badge-pass {
        background-color: #065F46;
        color: #34D399;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-weight: 600;
    }
    .badge-fail {
        background-color: #991B1B;
        color: #F87171;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">⚡ EvoForge SDLC Automation Platform</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Powered by CrewAI, Local Ollama LLM, and Requirement Traceability Graphs</div>', unsafe_allow_html=True)

# Sidebar Configuration
st.sidebar.header("⚙️ Platform Config")
st.sidebar.info(f"**LLM Model:** `{MODEL_NAME}`\n\n**Ollama Base:** `{OLLAMA_BASE_URL}`")

# List existing projects
existing_projects = []
if os.path.exists(PROJECTS_DIR):
    existing_projects = [d for d in os.listdir(PROJECTS_DIR) if os.path.isdir(os.path.join(PROJECTS_DIR, d))]

selected_project = st.sidebar.selectbox("📁 Select Active Project", options=["<None>"] + existing_projects)

tabs = st.tabs([
    "🚀 New Project",
    "🔄 Requirement Change",
    "🕸️ Traceability & Impact",
    "📄 SDLC Artifacts",
    "🧪 Test Execution & Debug",
    "📜 Git Versioning",
    "📊 Agent Evaluation"
])

# Tab 1: New Project
with tabs[0]:
    st.subheader("Create New Software Project")
    col1, col2 = st.columns([1, 1])
    with col1:
        proj_name = st.text_input("Project Identifier", placeholder="e.g. calculator_cli")
        req_input = st.text_area(
            "Natural-Language Client Requirements",
            height=200,
            placeholder="e.g. Build a command line calculator in Python supporting basic arithmetic (+, -, *, /) and power (^)."
        )
        if st.button("✨ Launch Agentic SDLC Pipeline", type="primary"):
            if not proj_name or not req_input:
                st.error("Please provide both project identifier and requirements.")
            else:
                with st.spinner("Agents are analyzing requirements, drafting SRS, generating code & test suite..."):
                    orchestrator = SDLCOrchestrator()
                    res, _ = run_with_evaluation(
                        orchestrator.run_initial_sdlc_pipeline, "initial", proj_name, req_input
                    )
                    st.success(f"Project '{proj_name}' created successfully!")
                    st.json(res)
                    st.rerun()

# Tab 2: Requirement Change
with tabs[1]:
    st.subheader("Incremental Requirement Change Engine")
    if selected_project == "<None>":
        st.warning("Please select a project from the sidebar first.")
    else:
        store = ProjectStore(selected_project)
        metadata = store.load_metadata()
        current_reqs = metadata.get("requirements", "")
        
        st.markdown(f"**Current Requirements for `{selected_project}`:**")
        st.text_area("Current Requirements", value=current_reqs, height=100, disabled=True)

        updated_reqs = st.text_area(
            "Updated Client Requirements",
            value=current_reqs,
            height=180,
            help="Modify or append requirements here."
        )

        if st.button("⚡ Propagate Requirement Change", type="primary"):
            with st.spinner("Agents detecting delta, conducting impact analysis, and updating affected artifacts..."):
                orchestrator = SDLCOrchestrator()
                res, _ = run_with_evaluation(
                    orchestrator.run_incremental_requirement_change, "change", selected_project, updated_reqs
                )
                st.success("Incremental change propagated successfully!")
                st.json(res)
                st.rerun()

# Tab 3: Traceability & Impact
with tabs[2]:
    st.subheader("Traceability Graph & Impact Analysis")
    if selected_project == "<None>":
        st.info("Select a project from the sidebar to inspect traceability graph.")
    else:
        store = ProjectStore(selected_project)
        graph = store.load_traceability_graph()
        st.markdown("**Artifact Dependency Graph Structure:**")
        st.json(graph.to_dict())

        delta_report = store.read_artifact("Requirement_Delta_Report.md")
        if delta_report:
            st.markdown("**Latest Requirement Delta & Impact Summary:**")
            st.code(delta_report, language="json")

# Tab 4: Artifacts Explorer
with tabs[3]:
    st.subheader("Generated SDLC Artifacts")
    if selected_project == "<None>":
        st.info("Select a project to view generated artifacts.")
    else:
        store = ProjectStore(selected_project)
        reports = store.list_reports()
        code_files = store.list_code_files()

        art_col1, art_col2 = st.columns([1, 2])
        with art_col1:
            all_files = [f"[Report] {r}" for r in reports] + [f"[Code] {c}" for c in code_files]
            selected_file = st.radio("Artifact Files", options=all_files)

        with art_col2:
            if selected_file:
                is_code = selected_file.startswith("[Code]")
                fname = selected_file.split(" ", 1)[1]
                content = store.read_artifact(fname, is_code=is_code)
                st.markdown(f"### `{fname}`")
                lang = "python" if fname.endswith(".py") else "markdown"
                st.code(content or "Empty file", language=lang)

# Tab 5: Test Execution & Debug
with tabs[4]:
    st.subheader("Automated Pytest & Agentic Debugging Log")
    if selected_project == "<None>":
        st.info("Select a project to run tests.")
    else:
        store = ProjectStore(selected_project)
        runner = PytestRunner(store.project_dir)

        if st.button("🧪 Run Pytest Suite Now"):
            with st.spinner("Running pytest suite..."):
                res = runner.run_tests()
                if res.get("passed"):
                    st.success("✅ ALL TESTS PASSED!")
                else:
                    st.error("❌ TESTS FAILED!")
                st.code(res.get("output", ""), language="text")

# Tab 6: Git Versioning
with tabs[5]:
    st.subheader("Git Commit History & Repository Diffs")
    if selected_project == "<None>":
        st.info("Select a project to inspect Git commit log.")
    else:
        store = ProjectStore(selected_project)
        git_mgr = GitManager(store.project_dir)
        commits = git_mgr.get_commit_history()
        
        st.markdown("**Repository Commit Log:**")
        for c in commits:
            st.markdown(f"- `{c['hexsha']}` | **{c['message']}** | *{c['authored_datetime']}*")

        latest_diff = git_mgr.get_latest_diff()
        if latest_diff:
            st.markdown("**Latest Commit Diff:**")
            st.code(latest_diff, language="diff")

# Tab 7: Agent Evaluation (6 metrics from the evaluation-metrics PDF, computed from the real run trace)
with tabs[6]:
    st.subheader("AI Agent Evaluation Metrics")
    if selected_project == "<None>":
        st.info("Select a project to view its agent evaluation report.")
    else:
        ev_dir = eval_dir(selected_project)
        report_json = os.path.join(ev_dir, "latest_evaluation_report.json")
        report_md = os.path.join(ev_dir, "latest_evaluation_report.md")

        if st.button("🔁 Re-evaluate latest recorded run"):
            try:
                evaluate_latest_trace(selected_project)
                st.success("Re-evaluated the latest execution trace.")
            except FileNotFoundError as e:
                st.warning(str(e))

        if not os.path.exists(report_json):
            st.info("No evaluation yet. Run a project creation or requirement change - evaluation is automatic.")
        else:
            with open(report_json, "r", encoding="utf-8") as f:
                ev = json.load(f)
            st.caption(
                f"Flow: **{ev['flow']}** | Pipeline: **{ev['pipeline_status']}** | Judge: {ev['judge']['summary']} | "
                f"Generated: {ev['generated_at']}"
            )
            st.caption(f"Rule: {ev['rule']}")
            st.table([
                {
                    "Metric": m["metric"],
                    "Score": round(m["score"], 3),
                    "Threshold": m["threshold"],
                    "Status": "✅ PASS" if m["status"] == "PASS" else "❌ FAIL",
                    "Scoring mode": m["mode"],
                }
                for m in ev["metrics"]
            ])
            for note in ev.get("notes", []):
                st.warning(note)
            for m in ev["metrics"]:
                with st.expander(f"{m['metric']} - {m['status']} ({m['score']:.3f} vs {m['threshold']})"):
                    st.markdown(f"**Definition:** {m['definition']}")
                    st.markdown(f"**Formula:** `{m['formula']}`")
                    st.markdown(f"**Calculation:** {m['calculation']}")
                    st.markdown(f"**Result:** {m['reason']}")
                    st.markdown(f"**Citation:** [{m['citation']['label']}]({m['citation']['url']})")
                    st.json({k: v for k, v in m["details"].items() if k != "per_call"})
            with st.expander("Tool-call log"):
                st.table(ev["tool_log"])
            if os.path.exists(report_md):
                with open(report_md, "r", encoding="utf-8") as f:
                    st.download_button("⬇️ Download evaluation report (Markdown)", f.read(),
                                       file_name=f"{selected_project}_evaluation_report.md")
