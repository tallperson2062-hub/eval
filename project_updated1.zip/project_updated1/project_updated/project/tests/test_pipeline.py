import os
import pytest
from core.project_store import ProjectStore
from core.git_manager import GitManager

def test_project_store_and_git_manager(tmp_path):
    proj_name = "test_store_proj"
    store = ProjectStore(proj_name)

    # Save artifact
    filepath = store.save_artifact("test_mod.py", "def hello(): pass\n", is_code=True)
    assert os.path.exists(filepath)

    content = store.read_artifact("test_mod.py", is_code=True)
    assert "def hello():" in content

    # Git manager
    git_mgr = GitManager(store.project_dir)
    hexsha = git_mgr.commit_all("Initial commit")
    assert hexsha is not None or len(git_mgr.get_commit_history()) >= 1
