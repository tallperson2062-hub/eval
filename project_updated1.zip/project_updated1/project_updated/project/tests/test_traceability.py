import pytest
from core.traceability import TraceabilityGraph

def test_traceability_graph_creation_and_impact():
    graph = TraceabilityGraph()
    graph.add_node("REQ_1", "requirement", "Basic Arithmetic", {"desc": "Add & Subtract"})
    graph.add_node("SRS_1", "srs", "SRS Section 1", {})
    graph.add_node("CODE_1", "code", "calculator.py", {})
    graph.add_node("TEST_1", "test", "test_calculator.py", {})

    graph.add_edge("REQ_1", "SRS_1")
    graph.add_edge("SRS_1", "CODE_1")
    graph.add_edge("CODE_1", "TEST_1")

    impact = graph.analyze_impact(["REQ_1"])
    assert impact["total_affected_count"] == 4
    assert "REQ_1" in impact["affected_node_ids"]
    assert "SRS_1" in impact["affected_node_ids"]
    assert "CODE_1" in impact["affected_node_ids"]
    assert "TEST_1" in impact["affected_node_ids"]

def test_requirement_change_detection():
    graph = TraceabilityGraph()
    old_req = "Requirement 1: Add addition\nRequirement 2: Add subtraction"
    new_req = "Requirement 1: Add addition\nRequirement 2: Add subtraction\nRequirement 3: Add multiplication"

    delta = graph.detect_changes(old_req, new_req)
    assert delta["is_changed"] is True
    assert len(delta["added_requirements"]) == 1
    assert "Requirement 3: Add multiplication" in delta["added_requirements"]
