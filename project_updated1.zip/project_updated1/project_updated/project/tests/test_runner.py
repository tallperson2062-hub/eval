import os
import shutil
import pytest
from core.runner import PytestRunner

def test_pytest_runner_execution(tmp_path):
    # Create sample python project in temp directory
    proj_dir = tmp_path / "sample_proj"
    proj_dir.mkdir()

    calc_file = proj_dir / "calc.py"
    calc_file.write_text("def add(a, b):\n    return a + b\n")

    test_file = proj_dir / "test_calc.py"
    test_file.write_text("from calc import add\ndef test_add():\n    assert add(2, 3) == 5\n")

    runner = PytestRunner(str(proj_dir))
    res = runner.run_tests()

    assert res["success"] is True
    assert res["passed"] is True
    assert res["exit_code"] == 0
