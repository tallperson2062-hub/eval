"""Tests for the AI-agent evaluation module (six PDF metrics).  No LLM / network needed."""
import json
import os
from types import SimpleNamespace

import pytest

from agents.prompt_templates import AGENT_ROLES
from evaluation import evaluator as ev
from evaluation import instrumentation
from evaluation.citations import CITATIONS
from evaluation.judge import LLMJudge, parse_json_object
from evaluation.metrics import (
    ArgumentCorrectnessMetric, PlanAdherenceMetric, PlanQualityMetric, StepEfficiencyMetric,
    TaskCompletionMetric, ToolCorrectnessMetric,
)
from evaluation.trace import ExecutionTrace, TraceRecorder

ROLE = {k: v["role"] for k, v in AGENT_ROLES.items()}
GOOD_CODE = (
    "def add(a, b):\n    return a + b\n\ndef subtract(a, b):\n    return a - b\n\n"
    "def multiply(a, b):\n    return a * b\n\n"
    "def divide(a, b):\n    if b == 0:\n        raise ValueError('Cannot divide by zero')\n    return a / b\n"
)
GOOD_TEST = "import pytest\nfrom calc import add, divide\n\ndef test_add():\n    assert add(1, 2) == 3\n"
REQS = "Build a calculator with add, subtract, multiply and divide. divide raises ValueError for zero."
PLAN = ("# Task Plan\n1. Analyze requirements for calculator\n2. Design module\n"
        "3. Implement calc.py with add, subtract, multiply, divide and ValueError handling\n"
        "4. Write pytest tests in test_calc.py\n5. Document usage in README.md\n")


def _crew(*role_keys):
    tasks = [SimpleNamespace(agent=SimpleNamespace(role=ROLE[k]), description=f"{k} task for calculator",
                             expected_output="x", output=None, callback=None) for k in role_keys]
    return SimpleNamespace(tasks=tasks)


def _make_trace(tmp_path, *, good=True, debug_loops=0, duplicate_reads=0):
    project = "calc"
    trace = ExecutionTrace(
        flow="initial", project_name=project, task_text=REQS,
        expected={"main_file": "calc.py", "test_file": "test_calc.py",
                  "project_dir": str(tmp_path / "projects" / project), "reports_dir": str(tmp_path / "reports" / project)},
    )
    os.makedirs(trace.expected["project_dir"], exist_ok=True)
    rec = TraceRecorder(trace)
    roles = ["requirements_analyst", "srs_author", "architect", "planner"]
    crew = _crew(*roles)
    cid = rec.begin_crew(crew)
    for i, r in enumerate(roles):
        rec.task_done(cid, i, PLAN if r == "planner" else f"{r} output text")
    rec.end_crew(cid, crew)
    crew2 = _crew("coder", "tester", "doc_writer")
    cid2 = rec.begin_crew(crew2)
    for i in range(3):
        rec.task_done(cid2, i, "output" if good else "")
    rec.end_crew(cid2, crew2)

    def tool(name, args, out=None, ok=True, ctx=None):
        rec.record_tool(name, args, ctx or {}, out, ok, None if ok else "boom", 0.01)

    code = GOOD_CODE if good else "def add(a, b) return a +"
    tool("save_artifact", {"filename": "calc.py", "content": code, "is_code": True})
    tool("save_artifact", {"filename": "test_calc.py", "content": GOOD_TEST, "is_code": True})
    tool("save_artifact", {"filename": "README.md", "content": "# Calc\nUsage docs for the calculator."})
    for _ in range(duplicate_reads):
        tool("read_artifact", {"filename": "README.md", "is_code": False}, {"found": True, "chars": 10})
    tool("commit_all", {"message": "Initial automated SDLC project generation"}, "abc")
    tool("run_tests", {"test_path": None}, {"passed": good, "exit_code": 0 if good else 1, "output": "x"},
         ctx={"project_dir": trace.expected["project_dir"]})
    for n in range(debug_loops):
        d = _crew("debugger")
        did = rec.begin_crew(d)
        rec.task_done(did, 0, "fixed")
        rec.end_crew(did, d)
        tool("extract_named_code_blocks", {"text": "```python\nx\n```"}, {"code_chars": 1, "test_chars": 0})
        tool("save_artifact", {"filename": "calc.py", "content": GOOD_CODE + f"# fix {n}\n", "is_code": True})
        tool("commit_all", {"message": f"Agentic Debug Fix attempt #{n + 1}"}, "def")
        tool("run_tests", {"test_path": None}, {"passed": True, "exit_code": 0, "output": "x"},
             ctx={"project_dir": trace.expected["project_dir"]})
    trace.outcome = {
        "pipeline_status": "COMPLETED", "tests_passed": good, "debug_attempts": debug_loops,
        "main_code": code, "test_code": GOOD_TEST,
        "files": {"calc.py": {"exists": True, "chars": len(code)}, "test_calc.py": {"exists": True, "chars": 50},
                  "README.md": {"exists": True, "chars": 30}},
    }
    return trace


@pytest.fixture
def heuristic_judge():
    return LLMJudge(mode="heuristic")


def _measure(cls, trace, judge, threshold=0.5, **kw):
    return cls(threshold, **kw).measure(trace, judge)


# ----------------------------------------------------------------------------------------- formulas
def test_scores_are_computed_from_the_trace_not_hardcoded(tmp_path, heuristic_judge):
    good, bad = _make_trace(tmp_path, good=True), _make_trace(tmp_path, good=False, debug_loops=2, duplicate_reads=2)
    for cls in (ArgumentCorrectnessMetric, TaskCompletionMetric, StepEfficiencyMetric, PlanAdherenceMetric):
        assert _measure(cls, good, heuristic_judge).score > _measure(cls, bad, heuristic_judge).score, cls.__name__
    assert _measure(TaskCompletionMetric, good, heuristic_judge).score > 0.9


def test_tool_correctness_is_correct_over_total_calls(tmp_path, heuristic_judge):
    trace = _make_trace(tmp_path)
    base = _measure(ToolCorrectnessMetric, trace, heuristic_judge)
    assert base.score == 1.0 and base.mode == "deterministic"
    n = len(trace.tool_calls)
    trace.tool_calls[0].name = "web_search"          # tool outside the expected set
    trace.tool_calls[1].success = False               # failed call
    res = _measure(ToolCorrectnessMetric, trace, heuristic_judge)
    assert res.score == pytest.approx((n - 2) / n)
    assert "web_search" in json.dumps(res.details["per_call"])


def test_argument_correctness_flags_invalid_arguments(tmp_path, heuristic_judge):
    trace = _make_trace(tmp_path, good=False)         # main module is not valid python
    res = _measure(ArgumentCorrectnessMetric, trace, heuristic_judge, 0.7)
    n = len(trace.tool_calls)
    assert res.score == pytest.approx((n - 1) / n)
    assert any("not valid Python" in p["why"] for p in res.details["per_call"])
    trace.tool_calls[2].arguments["is_code"] = True   # README written into the code dir
    assert _measure(ArgumentCorrectnessMetric, trace, heuristic_judge, 0.7).score == pytest.approx((n - 2) / n)


def test_step_efficiency_penalises_detours_and_duplicates(tmp_path, heuristic_judge):
    clean = _measure(StepEfficiencyMetric, _make_trace(tmp_path), heuristic_judge)
    assert clean.score == 1.0
    loops = _measure(StepEfficiencyMetric, _make_trace(tmp_path, debug_loops=2), heuristic_judge)
    dup = _measure(StepEfficiencyMetric, _make_trace(tmp_path, duplicate_reads=3), heuristic_judge)
    assert loops.score < 1.0 and loops.details["unnecessary_breakdown"]["debug-loop detour"] == 10
    assert dup.score < 1.0 and any("duplicate" in k for k in dup.details["unnecessary_breakdown"])


def test_plan_adherence_detects_skipped_steps_and_unwritten_files(tmp_path, heuristic_judge):
    trace = _make_trace(tmp_path)
    full = _measure(PlanAdherenceMetric, trace, heuristic_judge)
    trace.tasks = [t for t in trace.tasks if t.agent_role != ROLE["architect"]]   # architect step never executed
    skipped = _measure(PlanAdherenceMetric, trace, heuristic_judge)
    assert skipped.score < full.score and skipped.details["skipped_steps"]
    assert "test_calc.py" in full.details["planned_files"]


def test_plan_quality_penalises_an_empty_or_unrelated_plan(tmp_path, heuristic_judge):
    trace = _make_trace(tmp_path)
    good = _measure(PlanQualityMetric, trace, heuristic_judge)
    trace.plan_text = "# Plan\n- buy milk\n"
    assert _measure(PlanQualityMetric, trace, heuristic_judge).score < good.score


# ----------------------------------------------------------------------------------------- PASS / FAIL
def test_pass_fail_rule_is_score_ge_threshold(tmp_path, heuristic_judge):
    trace = _make_trace(tmp_path)
    exact = _measure(ToolCorrectnessMetric, trace, heuristic_judge, threshold=1.0)
    assert exact.score == 1.0 and exact.passed                      # Score >= Threshold -> PASS
    trace.tool_calls[0].success = False
    assert not _measure(ToolCorrectnessMetric, trace, heuristic_judge, threshold=1.0).passed
    strict = _measure(ArgumentCorrectnessMetric, _make_trace(tmp_path), heuristic_judge, 0.2, strict_mode=True)
    assert strict.threshold == 1.0                                   # strict mode -> threshold becomes 1


def test_default_thresholds_match_pdf():
    from evaluation.config import DEFAULT_THRESHOLDS
    assert DEFAULT_THRESHOLDS["tool_correctness"] == 0.5
    assert DEFAULT_THRESHOLDS["argument_correctness"] == 0.7
    assert DEFAULT_THRESHOLDS["task_completion"] == 0.7
    assert DEFAULT_THRESHOLDS["step_efficiency"] == 0.7


# ----------------------------------------------------------------------------------------- reports
def test_report_has_scores_thresholds_status_and_citations(tmp_path, monkeypatch, heuristic_judge):
    monkeypatch.chdir(tmp_path)
    trace = _make_trace(tmp_path)
    report = ev.AgentEvaluator(judge=heuristic_judge).evaluate(trace)
    assert len(report.results) == 6
    md = open(report.files["markdown"], encoding="utf-8").read()
    data = json.load(open(report.files["json"], encoding="utf-8"))
    for c in CITATIONS.values():
        assert c["url"] in md and any(m["citation"]["url"] == c["url"] for m in data["metrics"])
    for m in data["metrics"]:
        assert m["status"] in ("PASS", "FAIL") and "score" in m and "threshold" in m
    assert os.path.exists(report.files["trace"])
    reloaded = ev.evaluate_latest_trace("calc")                     # offline re-evaluation from the saved trace
    assert reloaded.scores().keys() == report.scores().keys()


def test_judge_falls_back_to_heuristic_when_llm_unreachable(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    judge = LLMJudge(mode="auto")
    monkeypatch.setattr(judge, "_get_llm", lambda: (_ for _ in ()).throw(ConnectionError("no ollama")))
    report = ev.AgentEvaluator(judge=judge).evaluate(_make_trace(tmp_path), write=False)
    modes = {m["metric"]: m["mode"] for m in report.to_dict()["metrics"]}
    assert modes["Task Completion"] == "heuristic" and modes["Tool Correctness"] == "deterministic"
    assert any("LLM judge unavailable" in n for n in report.to_dict()["notes"])


def test_llm_judge_scores_are_used_when_available(tmp_path, monkeypatch):
    judge = LLMJudge(mode="llm")
    monkeypatch.setattr(judge, "ask", lambda prompt: {"score": 0.25, "reason": "stub"} if '"score"' in prompt else
                        {"verdicts": [{"id": i + 1, "correct": True} for i in range(50)]})
    res = _measure(TaskCompletionMetric, _make_trace(tmp_path), judge, 0.7)
    assert res.mode == "llm" and res.score == 0.25 and not res.passed


def test_parse_json_object_handles_fences_and_noise():
    assert parse_json_object('```json\n{"score": 0.5, "reason": "x"}\n```')["score"] == 0.5
    assert parse_json_object("no json here") is None


# ----------------------------------------------------------------------------------------- instrumentation
def test_instrumentation_records_real_tool_calls_and_changes_nothing(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from core.project_store import ProjectStore
    from core.runner import PytestRunner

    store = ProjectStore("demo")
    store.save_artifact("x.py", "print(1)", is_code=True)          # outside a session: untouched, not recorded
    session = ev.EvaluationSession("initial", "demo", "do something")
    with session:
        path = store.save_artifact("mod.py", "def f():\n    return 1\n", is_code=True)
        store.save_artifact("test_mod.py", "from mod import f\ndef test_f():\n    assert f() == 1\n", is_code=True)
        text = store.read_artifact("mod.py", is_code=True)
        res = PytestRunner(store.project_dir).run_tests()
    assert os.path.exists(path) and text.startswith("def f") and res["passed"]
    names = [t.name for t in session.trace.tool_calls]
    assert names == ["save_artifact", "save_artifact", "read_artifact", "run_tests"]
    assert session.trace.tool_calls[0].arguments["filename"] == "mod.py"
    assert session.trace.tool_calls[3].output["passed"] is True
    assert instrumentation.get_recorder() is None                   # recording stops after the session


def test_run_with_evaluation_reports_even_if_pipeline_raises(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("EVAL_JUDGE", "heuristic")

    def boom(name, reqs):
        raise RuntimeError("pipeline exploded")

    with pytest.raises(RuntimeError, match="pipeline exploded"):
        ev.run_with_evaluation(boom, "initial", "broken", "reqs")
    last = ev._last["report"]
    assert last is not None and any("pipeline exploded" in n for n in last.to_dict()["notes"])


def test_run_with_evaluation_can_be_disabled(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result, report = ev.run_with_evaluation(lambda n, r: {"status": "OK"}, "initial", "p", "r", evaluate=False)
    assert result == {"status": "OK"} and report is None
