import os
import json
from typing import Dict, Any, List, Optional
from config.settings import PROJECTS_DIR, REPORTS_DIR
from core.traceability import TraceabilityGraph

class ProjectStore:
    """
    Manages filesystem persistence and metadata for generated projects and reports.
    """
    def __init__(self, project_name: str):
        self.project_name = project_name
        self.project_dir = os.path.abspath(os.path.join(PROJECTS_DIR, project_name))
        self.reports_dir = os.path.abspath(os.path.join(REPORTS_DIR, project_name))
        self._ensure_dirs()

    def _ensure_dirs(self):
        os.makedirs(self.project_dir, exist_ok=True)
        os.makedirs(self.reports_dir, exist_ok=True)

    def get_metadata_path(self) -> str:
        return os.path.join(self.reports_dir, "metadata.json")

    def save_metadata(self, data: Dict[str, Any]):
        with open(self.get_metadata_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def load_metadata(self) -> Dict[str, Any]:
        path = self.get_metadata_path()
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_artifact(self, filename: str, content: str, is_code: bool = False):
        """Saves artifact either to reports_dir (for docs/specs) or project_dir (for code/tests)."""
        target_dir = self.project_dir if is_code else self.reports_dir
        filepath = os.path.join(target_dir, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        return filepath

    def read_artifact(self, filename: str, is_code: bool = False) -> Optional[str]:
        target_dir = self.project_dir if is_code else self.reports_dir
        filepath = os.path.join(target_dir, filename)
        if not os.path.exists(filepath):
            return None
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()

    def list_code_files(self) -> List[str]:
        """Lists all files in project_dir."""
        files = []
        for root, _, filenames in os.walk(self.project_dir):
            if ".git" in root or "__pycache__" in root or ".pytest_cache" in root:
                continue
            for fn in filenames:
                rel = os.path.relpath(os.path.join(root, fn), self.project_dir)
                files.append(rel)
        return files

    def list_reports(self) -> List[str]:
        """Lists all files in reports_dir."""
        if not os.path.exists(self.reports_dir):
            return []
        return [f for f in os.listdir(self.reports_dir) if os.path.isfile(os.path.join(self.reports_dir, f))]

    def save_traceability_graph(self, graph: TraceabilityGraph):
        path = os.path.join(self.reports_dir, "traceability_graph.json")
        graph.save_to_json(path)

    def load_traceability_graph(self) -> TraceabilityGraph:
        path = os.path.join(self.reports_dir, "traceability_graph.json")
        return TraceabilityGraph.load_from_json(path)
