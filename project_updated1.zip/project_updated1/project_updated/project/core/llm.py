import os
from crewai import LLM
from config.settings import MODEL_NAME, OLLAMA_BASE_URL

def get_ollama_llm(model: str = None, base_url: str = None) -> LLM:
    """
    Returns a CrewAI LLM instance configured for local Ollama.
    """
    selected_model = model or MODEL_NAME
    selected_base_url = base_url or OLLAMA_BASE_URL
    
    # Format model string for CrewAI ollama provider if not already prefixed
    if not selected_model.startswith("ollama/"):
        model_string = f"ollama/{selected_model}"
    else:
        model_string = selected_model
        
    return LLM(
        model=model_string,
        base_url=selected_base_url,
        temperature=0.2
    )
