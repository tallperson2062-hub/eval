import json
import os
import networkx as nx
from typing import Dict, List, Set, Any, Tuple

class TraceabilityGraph:
    """
    Traceability and Dependency Graph for SDLC artifacts.
    Connects: Requirement -> SRS -> Design -> Task -> Code -> Test -> Documentation
    """
    def __init__(self):
        self.graph = nx.DiGraph()

    def add_node(self, node_id: str, node_type: str, label: str, metadata: Dict[str, Any] = None):
        """Add artifact node to traceability graph."""
        self.graph.add_node(
            node_id,
            node_type=node_type,
            label=label,
            metadata=metadata or {}
        )

    def add_edge(self, source_id: str, target_id: str, relation: str = "traces_to"):
        """Add directed edge between source and target artifact nodes."""
        if self.graph.has_node(source_id) and self.graph.has_node(target_id):
            self.graph.add_edge(source_id, target_id, relation=relation)

    def detect_changes(self, old_requirements: str, new_requirements: str) -> Dict[str, Any]:
        """
        Analyzes delta between old and new requirement specifications.
        Returns detailed requirement change report.
        """
        old_lines = [l.strip() for l in old_requirements.strip().split("\n") if l.strip()]
        new_lines = [l.strip() for l in new_requirements.strip().split("\n") if l.strip()]

        added = [l for l in new_lines if l not in old_lines]
        removed = [l for l in old_lines if l not in new_lines]
        unmodified = [l for l in new_lines if l in old_lines]

        is_changed = len(added) > 0 or len(removed) > 0

        return {
            "is_changed": is_changed,
            "added_requirements": added,
            "removed_requirements": removed,
            "unmodified_requirements": unmodified,
            "summary": f"Added: {len(added)}, Removed: {len(removed)}, Unchanged: {len(unmodified)}"
        }

    def analyze_impact(self, changed_node_ids: List[str]) -> Dict[str, Any]:
        """
        Performs downstream graph traversal from changed nodes to identify
        all affected artifacts across SRS, Design, Task, Code, Test, Doc layers.
        """
        affected_nodes: Set[str] = set(changed_node_ids)
        
        for node in changed_node_ids:
            if self.graph.has_node(node):
                # Get all downstream reachable nodes
                descendants = nx.descendants(self.graph, node)
                affected_nodes.update(descendants)
                
        # Categorize affected artifacts by node_type
        categorized: Dict[str, List[Dict[str, Any]]] = {
            "requirement": [],
            "srs": [],
            "design": [],
            "task": [],
            "code": [],
            "test": [],
            "doc": []
        }

        for nid in affected_nodes:
            if self.graph.has_node(nid):
                data = self.graph.nodes[nid]
                ntype = data.get("node_type", "other")
                item = {
                    "id": nid,
                    "label": data.get("label", nid),
                    "metadata": data.get("metadata", {})
                }
                if ntype in categorized:
                    categorized[ntype].append(item)
                else:
                    categorized.setdefault(ntype, []).append(item)

        return {
            "affected_node_ids": list(affected_nodes),
            "categorized_impact": categorized,
            "total_affected_count": len(affected_nodes)
        }

    def build_default_project_graph(self, req_list: List[str], code_files: List[str], test_files: List[str]):
        """Builds a standard traceability graph structure for a project."""
        self.graph.clear()
        
        # 1. Requirement Nodes
        for i, req in enumerate(req_list):
            req_id = f"REQ_{i+1}"
            self.add_node(req_id, "requirement", req, {"description": req})
            
            # Connect to SRS
            srs_id = f"SRS_SECTION_{i+1}"
            self.add_node(srs_id, "srs", f"SRS for {req_id}", {"req": req_id})
            self.add_edge(req_id, srs_id)
            
            # Connect SRS to Design
            design_id = f"DESIGN_SPEC_{i+1}"
            self.add_node(design_id, "design", f"Design Spec for {req_id}", {"srs": srs_id})
            self.add_edge(srs_id, design_id)

            # Connect Design to Task
            task_id = f"TASK_{i+1}"
            self.add_node(task_id, "task", f"Implementation Task {i+1}", {"design": design_id})
            self.add_edge(design_id, task_id)

        # Connect tasks to code files
        for cf in code_files:
            cf_id = f"CODE_{os.path.basename(cf)}"
            self.add_node(cf_id, "code", cf, {"path": cf})
            # Connect all tasks to code files by default
            for i in range(len(req_list)):
                self.add_edge(f"TASK_{i+1}", cf_id)
                
            # Connect code file to tests
            for tf in test_files:
                tf_id = f"TEST_{os.path.basename(tf)}"
                self.add_node(tf_id, "test", tf, {"path": tf})
                self.add_edge(cf_id, tf_id)

                # Connect test to doc
                doc_id = "DOC_README"
                self.add_node(doc_id, "doc", "README.md", {"path": "README.md"})
                self.add_edge(tf_id, doc_id)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize graph to dictionary format."""
        return nx.node_link_data(self.graph)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceabilityGraph":
        """Deserialize graph from dictionary format."""
        instance = cls()
        instance.graph = nx.node_link_graph(data)
        return instance

    def save_to_json(self, filepath: str):
        """Save graph to JSON file."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_from_json(cls, filepath: str) -> "TraceabilityGraph":
        """Load graph from JSON file."""
        if not os.path.exists(filepath):
            return cls()
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)
