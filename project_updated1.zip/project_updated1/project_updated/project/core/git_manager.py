import os
from typing import Optional, List
import git

class GitManager:
    """
    Manages Git operations (init, stage, commit, diff) for generated projects.
    """
    def __init__(self, project_path: str):
        self.project_path = os.path.abspath(project_path)
        self.repo: Optional[git.Repo] = None
        self._ensure_repo()

    def _ensure_repo(self):
        """Initializes or loads git repo at project_path."""
        os.makedirs(self.project_path, exist_ok=True)
        try:
            if os.path.exists(os.path.join(self.project_path, ".git")):
                self.repo = git.Repo(self.project_path)
            else:
                self.repo = git.Repo.init(self.project_path)
                # Config default committer if needed
                with self.repo.config_writer() as config:
                    config.set_value("user", "name", "EvoForge Bot")
                    config.set_value("user", "email", "evoforge@local.sdlc")
        except Exception as e:
            print(f"[GitManager Warning] Failed to initialize Git repo: {e}")
            self.repo = None

    def commit_all(self, message: str) -> Optional[str]:
        """Stage all files and commit with specified message."""
        if not self.repo:
            return None
        try:
            self.repo.git.add(A=True)
            if self.repo.is_dirty(untracked_files=True):
                commit = self.repo.index.commit(message)
                return commit.hexsha
            return None
        except Exception as e:
            print(f"[GitManager Error] Commit failed: {e}")
            return None

    def get_commit_history(self, limit: int = 10) -> List[dict]:
        """Get recent commits list."""
        if not self.repo:
            return []
        try:
            commits = []
            for c in list(self.repo.iter_commits(max_count=limit)):
                commits.append({
                    "hexsha": c.hexsha[:7],
                    "message": c.message.strip(),
                    "authored_datetime": str(c.authored_datetime)
                })
            return commits
        except Exception:
            return []

    def get_latest_diff(self) -> str:
        """Returns string representation of latest diff."""
        if not self.repo:
            return ""
        try:
            return self.repo.git.diff("HEAD~1", "HEAD")
        except Exception:
            return ""
