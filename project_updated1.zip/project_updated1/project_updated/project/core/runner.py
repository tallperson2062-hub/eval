import os
import sys
import subprocess
import time
from typing import Dict, Any

class PytestRunner:
    """
    Executes pytest programmatically in a generated project workspace
    and parses detailed pass/fail test results.
    """
    def __init__(self, project_dir: str):
        self.project_dir = os.path.abspath(project_dir)

    def run_tests(self, test_path: str = None) -> Dict[str, Any]:
        """
        Executes pytest in project_dir.
        Returns detailed status report.
        """
        if not os.path.exists(self.project_dir):
            return {
                "success": False,
                "exit_code": -1,
                "output": f"Project directory '{self.project_dir}' does not exist.",
                "duration_seconds": 0.0,
                "passed": False
            }

        cmd = [sys.executable, "-m", "pytest", "-v"]
        if test_path:
            cmd.append(test_path)

        start_time = time.time()
        try:
            result = subprocess.run(
                cmd,
                cwd=self.project_dir,
                capture_output=True,
                text=True,
                timeout=60
            )
            duration = round(time.time() - start_time, 2)
            exit_code = result.returncode
            stdout = result.stdout or ""
            stderr = result.stderr or ""
            full_output = stdout + ("\n--- STDERR ---\n" + stderr if stderr else "")

            passed = (exit_code == 0)

            return {
                "success": True,
                "passed": passed,
                "exit_code": exit_code,
                "output": full_output,
                "duration_seconds": duration,
                "cmd": " ".join(cmd)
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "passed": False,
                "exit_code": -2,
                "output": "Pytest execution timed out after 60 seconds.",
                "duration_seconds": 60.0
            }
        except Exception as e:
            return {
                "success": False,
                "passed": False,
                "exit_code": -3,
                "output": f"Error running pytest: {str(e)}",
                "duration_seconds": round(time.time() - start_time, 2)
            }
