# EvoForge + Agent Evaluation - Requirements & How to Run

## 1. Requirements

### System
| Requirement | Details |
|---|---|
| Python | 3.11 or newer (`environment.yml` pins 3.11; tested on 3.12) |
| Git | The `git` executable must be installed and on PATH (GitPython needs it) |
| Ollama | Installed and running locally (default `http://localhost:11434`) |
| Ollama model | `llama3.2:latest` (default) or any model you set in `.env` |
| OS | Windows / Linux / macOS |

### Python packages (from `requirements.txt`)
```
crewai>=0.80.0
streamlit>=1.30.0
networkx>=3.0
gitpython>=3.1.0
pytest>=7.4.0
pydantic>=2.5.0
python-dotenv>=1.0.0
langchain-community>=0.0.10
```
The evaluation module adds **no new dependencies** (standard library + the packages above).

### Configuration (`.env`)
```
MODEL_NAME=llama3.2:latest
OLLAMA_BASE_URL=http://127.0.0.1:11434
PROJECTS_DIR=projects
REPORTS_DIR=reports
LOG_LEVEL=INFO
```
Optional evaluation settings (defaults shown; all optional, see `.env.example`):
```
EVAL_ENABLED=true          # false = never evaluate
EVAL_JUDGE=auto            # auto | llm | heuristic | blend
EVAL_JUDGE_MODEL=          # defaults to MODEL_NAME
EVAL_JUDGE_TIMEOUT=180
EVAL_STRICT_MODE=false     # true = Tool/Argument Correctness threshold becomes 1
EVAL_THRESHOLD_PLAN_QUALITY=0.5
EVAL_THRESHOLD_PLAN_ADHERENCE=0.5
EVAL_THRESHOLD_TOOL_CORRECTNESS=0.5
EVAL_THRESHOLD_ARGUMENT_CORRECTNESS=0.7
EVAL_THRESHOLD_TASK_COMPLETION=0.7
EVAL_THRESHOLD_STEP_EFFICIENCY=0.7
```

## 2. Setup

```bash
# 1. Unzip and enter the project
unzip project_updated.zip
cd project

# 2. Create an environment (pick one)
conda env create -f environment.yml && conda activate evoforge_env
#   or
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. Start Ollama and pull the model
ollama serve                       # skip if Ollama already runs as a service
ollama pull llama3.2:latest

# 4. Check the configuration
cp .env.example .env               # only if you do not already have a .env
```

## 3. How to execute

Run all commands from the `project/` folder. Evaluation is **automatic** after every run.

### Create a new project (runs the pipeline, then prints the evaluation table)
```bash
python main.py create --name calc --requirements "Build a Python calculator module with add, subtract, multiply and divide. divide must raise ValueError when b is 0."
```
`--requirements` also accepts a path to a text file.

### Apply a requirement change to an existing project
```bash
python main.py change --name calc --requirements "Build a Python calculator module with add, subtract, multiply and divide. divide must raise ValueError when b is 0.
5. power(base, exponent): Returns base raised to the power of exponent."
```

### Re-evaluate the latest recorded run (no LLM pipeline re-run)
```bash
python main.py evaluate --name calc
```
Use this after changing thresholds or the judge mode in `.env`.

### Run the pytest suite of a generated project
```bash
python main.py test --name calc
```

### End-to-end demo (creates `demo_calculator`, applies a change, prints both evaluations)
```bash
python demo/run_demo.py
```

### Streamlit UI (new tab: "📊 Agent Evaluation")
```bash
streamlit run app.py
```

### Skip evaluation
```bash
python main.py create --name calc --requirements "..." --no-eval
# or set EVAL_ENABLED=false in .env
```

### Run the tests of the repo (no LLM needed)
```bash
python -m pytest tests -q
```

## 4. What you get

Terminal output after each run: a table with **Score, Threshold, PASS/FAIL, Scoring mode** for Plan Quality, Plan Adherence, Tool Correctness, Argument Correctness, Task Completion and Step Efficiency, plus a reason and the citation link for each metric.

Saved files in `reports/<project>/evaluation/`:

| File | Content |
|---|---|
| `latest_evaluation_report.md` | Full report: scores, thresholds, status, evidence, tool-call log, timeline, PDF citation links |
| `latest_evaluation_report.json` | Same data, machine-readable |
| `latest_trace.json` | The recorded execution trace the scores were computed from |
| `evaluation_report_<flow>_<timestamp>.*`, `trace_<flow>_<timestamp>.json` | Timestamped copies of every run |

Pass rule (from the PDF): **Score >= Threshold = PASS, Score < Threshold = FAIL.**

## 5. Judge modes

| `EVAL_JUDGE` | Behaviour |
|---|---|
| `auto` (default) | Uses the Ollama model as LLM judge; falls back to trace-derived scoring if Ollama is unreachable |
| `llm` | LLM judge only (still falls back if unreachable) |
| `heuristic` | Never calls the LLM; trace-derived scoring only |
| `blend` | Mean of the LLM score and the trace-derived score |

Tool Correctness is always deterministic. The report's "Scoring mode" column shows what produced each score.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `Failed to connect ... Connection error` | Ollama is not running or `OLLAMA_BASE_URL` is wrong; run `ollama serve` |
| Model not found | `ollama pull <MODEL_NAME>` |
| `git` errors / `GitManager Warning` | Install Git and make sure it is on PATH |
| `No execution trace found` on `evaluate` | Run `create` or `change` once first; existing old projects have no trace |
| Judge notes say "LLM judge unavailable" | Ollama unreachable during evaluation; scores used trace-derived mode. Check Ollama, or set `EVAL_JUDGE=heuristic` |
| Slow evaluation | Lower `EVAL_JUDGE_TIMEOUT` or use `EVAL_JUDGE=heuristic` |
| Windows: garbled colors | Set `NO_COLOR=1` |

## 7. Project layout (new parts)

```
evaluation/
  config.py            thresholds, judge mode, env settings
  citations.py         PDF citation links
  trace.py             execution-trace data model + recorder
  instrumentation.py   non-intrusive recording wrappers
  tool_specs.py        expected tools + argument contracts
  judge.py             LLM judge (Ollama) with fallback
  metrics.py           the six metrics
  report.py            terminal / Markdown / JSON output
  evaluator.py         sessions, evaluation, public API
tests/test_evaluation.py
EVALUATION.md          design and metric details
```
